Friday Night Dynasty 2026 — local play (Windows)

This folder is a portable copy of the game. You do not need to install Python.

HOW TO PLAY
1. Unzip this folder anywhere (Desktop is fine). Keep all files together.
2. Double-click "Start Friday Night Dynasty.bat".
3. Your browser should open http://127.0.0.1:8001/
   If it does not, open that address yourself (use http, not https).
4. Enter a coach name to play (this is a local login, not the website).
5. Leave the black window open while you play. Close it when you are done.

SAVES
Your dynasties are stored in the "userdata" folder next to the game.
Copy that folder to back up your progress.

NOTES
- Windows 10/11, 64-bit.
- First start may be slow while Windows Defender scans the bundled Python.
- Online multiplayer from the old website is not included.
- If port 8001 is in use, close other copies of the game first.

To stop the game: close the game tab, then press Ctrl+C in the black window (or close that window).
