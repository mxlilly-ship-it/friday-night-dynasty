@echo off
cd /d "%~dp0"
title Friday Night Dynasty 2026
set FND_SKIP_SPA_AUTO_BUILD=1
set FND_IGNORE_STALE_SPA=1
set FND_ALLOW_DEV_LOGIN=true
set FND_OPEN_BROWSER=1
set FND_DATA_DIR=%~dp0userdata
set PYTHONPATH=%~dp0
set PYTHONUTF8=1
set PYTHONDONTWRITEBYTECODE=1
if not exist "%~dp0python\python.exe" (
  echo Bundled Python is missing. Re-download the zip.
  pause
  exit /b 1
)
if not exist "%~dp0frontend\dist\index.html" (
  echo Game UI is missing ^(frontend\dist^). Re-download the zip.
  pause
  exit /b 1
)
echo.
echo  Friday Night Dynasty 2026
echo  Starting local server...
echo  Keep this window open while you play.
echo.
"%~dp0python\python.exe" "%~dp0run_game.py"
echo.
echo Server stopped.
pause
