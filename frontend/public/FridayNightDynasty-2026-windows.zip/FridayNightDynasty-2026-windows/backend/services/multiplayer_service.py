"""Multiplayer league registry and league dashboard payloads."""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import secrets
import shutil
import time
import uuid
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple
from zoneinfo import ZoneInfo

from backend.data_paths import leagues_base_dir
from backend.platform_config import is_platform_owner_email
from backend.storage.db import db
from systems.save_system import coach_from_dict, coach_to_dict
from systems.win_path_io import (
    isfile_any,
    makedirs_with_path_fallback,
    open_text_with_path_fallback,
    os_replace_with_path_fallback,
    unlink_if_exists_any,
)

logger = logging.getLogger(__name__)

LEAGUE_SAVE_FILENAME = "league_save.json"


def _now() -> int:
    return int(time.time())


def _hash_pin(pin: str) -> str:
    return hashlib.sha256(pin.strip().encode("utf-8")).hexdigest()


def generate_team_pin() -> str:
    return f"{secrets.randbelow(1_000_000):06d}"


def _league_dir(league_id: str) -> str:
    return os.path.join(leagues_base_dir(), league_id)


def _league_save_path(save_dir: str) -> str:
    return os.path.join(save_dir, LEAGUE_SAVE_FILENAME)


def _load_league_row(league_id: str) -> Optional[Dict[str, Any]]:
    with db() as conn:
        row = conn.execute("SELECT * FROM leagues WHERE id=?", (league_id,)).fetchone()
    return dict(row) if row else None


def _reject_deleted_league(league_row: Dict[str, Any]) -> None:
    if str(league_row.get("status") or "") == "deleted":
        raise ValueError("league not found")


def _user_email(user_id: str) -> str:
    with db() as conn:
        row = conn.execute("SELECT email, username FROM users WHERE id=?", (user_id,)).fetchone()
    if not row:
        return ""
    return str(row["email"] or row["username"] or "").strip()


def account_identity_for_user(user_id: str) -> Dict[str, Any]:
    """Email/username used for platform-owner checks (for diagnostics)."""
    with db() as conn:
        row = conn.execute("SELECT email, username FROM users WHERE id=?", (user_id,)).fetchone()
    if not row:
        return {"email": "", "username": ""}
    return {
        "email": str(row["email"] or "").strip(),
        "username": str(row["username"] or "").strip(),
    }


def is_platform_owner_user(user_id: str) -> bool:
    identity = account_identity_for_user(user_id)
    for field in (identity.get("email"), identity.get("username")):
        if is_platform_owner_email(str(field or "")):
            return True
    return False


def _team_initials(name: str) -> str:
    parts = re.findall(r"[A-Za-z0-9]+", name or "")
    if not parts:
        return "??"
    if len(parts) == 1:
        return parts[0][:2].upper()
    return (parts[0][:1] + parts[1][:1]).upper()


def _record_label(team: Dict[str, Any], standings: Dict[str, Any]) -> str:
    name = str(team.get("name") or "")
    row = standings.get(name) if isinstance(standings, dict) else None
    if isinstance(row, dict):
        w = int(row.get("wins", 0) or 0)
        l = int(row.get("losses", 0) or 0)
        return f"{w}-{l}"
    return "0-0"


def _division_key(team: Dict[str, Any]) -> str:
    cls = str(team.get("classification") or "League").strip() or "League"
    region = str(team.get("region") or "").strip()
    if region:
        return f"{cls} · Region {region}"
    return cls


def _stage_key_from_state(state: Dict[str, Any]) -> str:
    phase = str(state.get("season_phase") or "regular").strip().lower()
    if phase == "regular":
        wk = int(state.get("current_week", 1) or 1)
        return f"regular:week:{wk}"
    if phase == "preseason":
        stages = state.get("preseason_stages") or []
        idx = int(state.get("preseason_stage_index", 0) or 0)
        label = str(stages[idx]) if isinstance(stages, list) and 0 <= idx < len(stages) else "preseason"
        return f"preseason:{label}"
    if phase == "offseason":
        stages = state.get("offseason_stages") or []
        idx = int(state.get("offseason_stage_index", 0) or 0)
        label = str(stages[idx]) if isinstance(stages, list) and 0 <= idx < len(stages) else "offseason"
        return f"offseason:{label}"
    if phase == "playoffs":
        return "playoffs:round"
    return f"{phase}:stage"


def _read_league_save_json(path: str) -> Dict[str, Any]:
    """Load league_save.json with brief retry and .bak fallback (avoids mid-write empty reads)."""
    bak_path = f"{path}.bak"
    paths = [path]
    if isfile_any(bak_path):
        paths.append(bak_path)
    last_err: Optional[BaseException] = None
    for attempt in range(5):
        for candidate in paths:
            if not isfile_any(candidate):
                continue
            try:
                with open_text_with_path_fallback(candidate, "r") as f:
                    raw = f.read()
                if not raw.strip():
                    last_err = ValueError("league save file is empty")
                    continue
                data = json.loads(raw)
                if not isinstance(data, dict):
                    last_err = ValueError("league save root must be an object")
                    continue
                return data
            except json.JSONDecodeError as exc:
                last_err = exc
            except OSError as exc:
                last_err = exc
        if attempt < 4:
            time.sleep(0.05 * (attempt + 1))
    if last_err:
        raise ValueError(f"Could not read league save: {last_err}") from last_err
    raise ValueError("league save file missing")


def _load_state_for_list(save_dir: str) -> Dict[str, Any]:
    """Best-effort league save read for league list badges (no long retry loop)."""
    path = _league_save_path(save_dir)
    if not isfile_any(path):
        return {}
    try:
        with open_text_with_path_fallback(path, "r") as f:
            raw = f.read()
        if not raw.strip():
            return {}
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _load_state(save_dir: str) -> Dict[str, Any]:
    path = _league_save_path(save_dir)
    return _read_league_save_json(path)


def _save_state(save_dir: str, state: Dict[str, Any]) -> None:
    from systems.game_stats import season_stats_map_from_jsonable, season_stats_map_to_jsonable

    path = _league_save_path(save_dir)
    try:
        makedirs_with_path_fallback(os.path.abspath(os.path.normpath(save_dir)))
    except OSError:
        try:
            os.makedirs(save_dir, exist_ok=True)
        except OSError:
            pass
    raw_ps = state.get("playoff_season_player_stats")
    if raw_ps:
        state["playoff_season_player_stats"] = season_stats_map_to_jsonable(
            season_stats_map_from_jsonable(raw_ps)
        )
    payload = json.dumps(state, indent=2, ensure_ascii=False)
    bak_path = f"{path}.bak"
    try:
        if isfile_any(path):
            with open_text_with_path_fallback(path, "r") as f:
                current = f.read()
            if current.strip():
                with open_text_with_path_fallback(bak_path, "w") as f:
                    f.write(current)
    except OSError:
        pass
    tmp_plain = f"{path}.tmp.{uuid.uuid4().hex}"
    try:
        with open_text_with_path_fallback(tmp_plain, "w") as f:
            f.write(payload)
        os_replace_with_path_fallback(tmp_plain, path)
    except OSError as err:
        try:
            with open_text_with_path_fallback(path, "w") as f:
                f.write(payload)
            try:
                unlink_if_exists_any(tmp_plain)
            except OSError:
                pass
        except OSError:
            try:
                unlink_if_exists_any(tmp_plain)
            except OSError:
                pass
            raise err


def sync_pending_invites_for_user(user_id: str) -> None:
    """Accept pending email invites — adds user as unassigned league member."""
    email = _user_email(user_id).strip().lower()
    if not email or "@" not in email:
        return
    now = _now()
    with db() as conn:
        invites = conn.execute(
            """
            SELECT id, league_id FROM league_invites
            WHERE lower(trim(email))=? AND status='pending'
            """,
            (email,),
        ).fetchall()
        for inv in invites:
            league_id = str(inv["league_id"])
            exists = conn.execute(
                """
                SELECT 1 FROM league_members
                WHERE league_id=? AND user_id=? AND status != 'removed'
                """,
                (league_id, user_id),
            ).fetchone()
            if not exists:
                conn.execute(
                    """
                    INSERT INTO league_members (
                      id, league_id, user_id, team_name, role, status,
                      control_mode, coach_setup_complete, joined_at
                    ) VALUES (?,?,?,?,?,?,?,?,?)
                    """,
                    (
                        str(uuid.uuid4()),
                        league_id,
                        user_id,
                        None,
                        "coach",
                        "unassigned",
                        "human",
                        0,
                        now,
                    ),
                )
            conn.execute(
                "UPDATE league_invites SET status='accepted' WHERE id=?",
                (str(inv["id"]),),
            )


def invite_user_to_league(league_id: str, actor_user_id: str, email: str) -> Dict[str, Any]:
    league_row = _require_commish_write(league_id, actor_user_id)
    clean = email.strip().lower()
    if not clean or "@" not in clean:
        raise ValueError("valid email required")
    existing_user = lookup_user_by_email(clean)
    now = _now()
    invite_id = str(uuid.uuid4())
    with db() as conn:
        pending = conn.execute(
            """
            SELECT id FROM league_invites
            WHERE league_id=? AND lower(trim(email))=? AND status='pending'
            """,
            (league_id, clean),
        ).fetchone()
        if pending:
            raise ValueError(f"{clean} already has a pending invite")
        if existing_user:
            member = conn.execute(
                """
                SELECT status FROM league_members
                WHERE league_id=? AND user_id=? AND status != 'removed'
                """,
                (league_id, str(existing_user["user_id"])),
            ).fetchone()
            if member:
                raise ValueError(f"{clean} is already in this league")
        conn.execute(
            """
            INSERT INTO league_invites (id, league_id, email, status, created_by_user_id, created_at)
            VALUES (?,?,?,?,?,?)
            """,
            (invite_id, league_id, clean, "pending", actor_user_id, now),
        )
        conn.execute(
            """
            INSERT INTO league_activity_log (id, league_id, actor_user_id, action, detail_json, created_at)
            VALUES (?,?,?,?,?,?)
            """,
            (
                str(uuid.uuid4()),
                league_id,
                actor_user_id,
                "invite_sent",
                json.dumps({"text": f"Invited {clean}", "icon": "✉️"}),
                now,
            ),
        )

    email_sent = False
    try:
        from backend.email_notify import send_league_invite_email

        inviter = _user_email(actor_user_id) or "Your commissioner"
        email_sent = send_league_invite_email(
            to_email=clean,
            league_name=str(league_row.get("name") or "League"),
            inviter_label=inviter,
        )
    except Exception:
        email_sent = False
    return {
        "invite_id": invite_id,
        "email": clean,
        "status": "pending",
        "email_sent": email_sent,
    }


def list_browsable_leagues(user_id: str) -> List[Dict[str, Any]]:
    """Active leagues the user is not in, with vacant team counts and join-request state."""
    with db() as conn:
        rows = conn.execute(
            """
            SELECT l.id, l.name, l.updated_at, l.save_dir
            FROM leagues l
            WHERE l.status = 'active'
              AND l.id NOT IN (
                SELECT league_id FROM league_members
                WHERE user_id = ? AND status != 'removed'
              )
            ORDER BY l.updated_at DESC
            """,
            (user_id,),
        ).fetchall()
        pending_rows = conn.execute(
            """
            SELECT id, league_id FROM league_join_requests
            WHERE user_id=? AND status='pending'
            """,
            (user_id,),
        ).fetchall()
    pending_by_league = {str(r["league_id"]): str(r["id"]) for r in pending_rows}

    out: List[Dict[str, Any]] = []
    for r in rows:
        league_id = str(r["id"])
        save_dir = str(r["save_dir"] or "")
        vacant = 0
        try:
            state = _load_state(save_dir)
            teams_meta = _teams_meta_from_state(state)
            all_teams = set(teams_meta.keys())
            with db() as conn:
                assigned = {
                    str(row["team_name"])
                    for row in conn.execute(
                        """
                        SELECT team_name FROM league_members
                        WHERE league_id=? AND status='active' AND team_name IS NOT NULL
                        """,
                        (league_id,),
                    ).fetchall()
                    if row["team_name"]
                }
            vacant = len([t for t in all_teams if t not in assigned])
        except Exception:
            vacant = 0
        pending_id = pending_by_league.get(league_id)
        out.append(
            {
                "league_id": league_id,
                "name": str(r["name"] or ""),
                "updated_at": int(r["updated_at"] or 0),
                "vacant_teams": vacant,
                "join_request_status": "pending" if pending_id else None,
                "join_request_id": pending_id,
            }
        )
    return out


def create_join_request(
    league_id: str,
    user_id: str,
    message: Optional[str] = None,
) -> Dict[str, Any]:
    league_row = _load_league_row(league_id)
    if not league_row:
        raise ValueError("league not found")
    if str(league_row.get("status") or "") != "active":
        raise ValueError("this league is not accepting join requests")

    clean_msg = (message or "").strip()[:500] or None
    now = _now()
    request_id = str(uuid.uuid4())
    with db() as conn:
        member = conn.execute(
            """
            SELECT 1 FROM league_members
            WHERE league_id=? AND user_id=? AND status != 'removed'
            """,
            (league_id, user_id),
        ).fetchone()
        if member:
            raise ValueError("you are already in this league")
        pending = conn.execute(
            """
            SELECT id FROM league_join_requests
            WHERE league_id=? AND user_id=? AND status='pending'
            """,
            (league_id, user_id),
        ).fetchone()
        if pending:
            raise ValueError("you already have a pending join request for this league")
        conn.execute(
            """
            INSERT INTO league_join_requests (
              id, league_id, user_id, status, message, created_at
            ) VALUES (?,?,?,?,?,?)
            """,
            (request_id, league_id, user_id, "pending", clean_msg, now),
        )
        requester_label = _user_email(user_id) or "A coach"
        conn.execute(
            """
            INSERT INTO league_activity_log (id, league_id, actor_user_id, action, detail_json, created_at)
            VALUES (?,?,?,?,?,?)
            """,
            (
                str(uuid.uuid4()),
                league_id,
                user_id,
                "join_request",
                json.dumps({"text": f"{requester_label} requested to join", "icon": "🙋"}),
                now,
            ),
        )

    email_sent = False
    commish_id = str(league_row.get("commissioner_user_id") or "").strip()
    if commish_id:
        commish_email = _user_email(commish_id)
        if commish_email:
            try:
                from backend.email_notify import send_join_request_email_to_commish

                requester_label = _user_email(user_id) or "A coach"
                email_sent = send_join_request_email_to_commish(
                    to_email=commish_email,
                    league_name=str(league_row.get("name") or "League"),
                    requester_label=requester_label,
                    message=clean_msg,
                )
            except Exception:
                email_sent = False

    return {
        "request_id": request_id,
        "league_id": league_id,
        "status": "pending",
        "email_sent": email_sent,
    }


def approve_join_request(
    league_id: str,
    actor_user_id: str,
    request_id: str,
    *,
    team_name: Optional[str] = None,
) -> Dict[str, Any]:
    league_row = _require_commish_write(league_id, actor_user_id)
    with db() as conn:
        req = conn.execute(
            """
            SELECT id, user_id, status FROM league_join_requests
            WHERE id=? AND league_id=?
            """,
            (request_id, league_id),
        ).fetchone()
        if not req or str(req["status"]) != "pending":
            raise ValueError("join request not found or already resolved")
        target_user_id = str(req["user_id"])

    now = _now()
    pin: Optional[str] = None
    assigned_team: Optional[str] = None
    if team_name:
        result = assign_team_to_member(league_id, actor_user_id, target_user_id, team_name)
        assigned_team = str(result.get("team_name") or team_name)
        pin = str(result.get("pin") or "")
    else:
        with db() as conn:
            exists = conn.execute(
                """
                SELECT 1 FROM league_members
                WHERE league_id=? AND user_id=? AND status != 'removed'
                """,
                (league_id, target_user_id),
            ).fetchone()
            if not exists:
                conn.execute(
                    """
                    INSERT INTO league_members (
                      id, league_id, user_id, team_name, role, status,
                      control_mode, coach_setup_complete, joined_at
                    ) VALUES (?,?,?,?,?,?,?,?,?)
                    """,
                    (
                        str(uuid.uuid4()),
                        league_id,
                        target_user_id,
                        None,
                        "coach",
                        "unassigned",
                        "human",
                        0,
                        now,
                    ),
                )

    with db() as conn:
        conn.execute(
            """
            UPDATE league_join_requests
            SET status='accepted', resolved_at=?, resolved_by_user_id=?
            WHERE id=? AND league_id=?
            """,
            (now, actor_user_id, request_id, league_id),
        )
        requester_label = _user_email(target_user_id) or "Coach"
        detail = f"Approved join request from {requester_label}"
        if assigned_team:
            detail += f" — assigned {assigned_team}"
        conn.execute(
            """
            INSERT INTO league_activity_log (id, league_id, actor_user_id, action, detail_json, created_at)
            VALUES (?,?,?,?,?,?)
            """,
            (
                str(uuid.uuid4()),
                league_id,
                actor_user_id,
                "join_request_approved",
                json.dumps({"text": detail, "icon": "✅"}),
                now,
            ),
        )

    out: Dict[str, Any] = {
        "ok": True,
        "request_id": request_id,
        "user_id": target_user_id,
        "team_name": assigned_team,
    }
    if pin:
        out["pin"] = pin
    return out


def reject_join_request(league_id: str, actor_user_id: str, request_id: str) -> Dict[str, Any]:
    _require_commish_write(league_id, actor_user_id)
    now = _now()
    with db() as conn:
        req = conn.execute(
            """
            SELECT id, user_id, status FROM league_join_requests
            WHERE id=? AND league_id=?
            """,
            (request_id, league_id),
        ).fetchone()
        if not req or str(req["status"]) != "pending":
            raise ValueError("join request not found or already resolved")
        target_user_id = str(req["user_id"])
        conn.execute(
            """
            UPDATE league_join_requests
            SET status='rejected', resolved_at=?, resolved_by_user_id=?
            WHERE id=? AND league_id=?
            """,
            (now, actor_user_id, request_id, league_id),
        )
        requester_label = _user_email(target_user_id) or "Coach"
        conn.execute(
            """
            INSERT INTO league_activity_log (id, league_id, actor_user_id, action, detail_json, created_at)
            VALUES (?,?,?,?,?,?)
            """,
            (
                str(uuid.uuid4()),
                league_id,
                actor_user_id,
                "join_request_rejected",
                json.dumps({"text": f"Denied join request from {requester_label}", "icon": "🚫"}),
                now,
            ),
        )
    return {"ok": True, "request_id": request_id}


def apply_member_coach_setup(
    league_id: str,
    user_id: str,
    team_name: str,
    coach_config: Dict[str, Any],
) -> Dict[str, Any]:
    """Apply a human coach profile to their assigned team in the shared league save."""
    from models.coach import apply_coach_config_dict

    league_row = _load_league_row(league_id)
    if not league_row:
        raise ValueError("league not found")
    save_dir = str(league_row.get("save_dir") or "")
    if not save_dir:
        raise ValueError("league save missing")

    with db() as conn:
        mem = conn.execute(
            """
            SELECT team_name, status FROM league_members
            WHERE league_id=? AND user_id=? AND team_name=? AND status='active'
            """,
            (league_id, user_id, team_name),
        ).fetchone()
    if not mem:
        raise PermissionError("team not assigned to you")

    state = _load_state(save_dir)
    teams = state.get("teams") or []
    target: Optional[Dict[str, Any]] = None
    for row in teams:
        if isinstance(row, dict) and str(row.get("name") or "") == team_name:
            target = row
            break
    if not target:
        raise ValueError("team not found in league save")

    coach_dict = target.get("coach") if isinstance(target.get("coach"), dict) else {}
    coach = coach_from_dict(coach_dict)
    apply_coach_config_dict(coach, coach_config)
    # League creation locks CPU teams' playbooks for the current year; human coaches must be able to pick.
    coach.last_preferred_playbook_change_year = 0
    target["coach"] = coach_to_dict(coach)

    coach_name = str(coach_config.get("name") or coach.name or "").strip()
    if coach_name:
        mp_coaches = state.get("multiplayer_coach_names")
        if not isinstance(mp_coaches, dict):
            mp_coaches = {}
        mp_coaches[team_name] = coach_name
        state["multiplayer_coach_names"] = mp_coaches

    _save_state(save_dir, state)
    now = _now()
    with db() as conn:
        conn.execute(
            """
            UPDATE league_members SET coach_setup_complete=1
            WHERE league_id=? AND user_id=? AND team_name=?
            """,
            (league_id, user_id, team_name),
        )
        conn.execute(
            "UPDATE leagues SET state_version=state_version+1, updated_at=? WHERE id=?",
            (now, league_id),
        )
    return {"ok": True, "team_name": team_name, "coach_name": coach_name}


def lookup_user_by_email(email: str) -> Optional[Dict[str, Any]]:
    """Find a registered user by email or username (exact match, case-insensitive)."""
    clean = str(email or "").strip().lower()
    if not clean:
        return None
    with db() as conn:
        row = conn.execute(
            """
            SELECT id, email, username FROM users
            WHERE lower(trim(coalesce(email, ''))) = ?
               OR lower(trim(username)) = ?
            LIMIT 1
            """,
            (clean, clean),
        ).fetchone()
    if not row:
        return None
    return {
        "user_id": str(row["id"]),
        "email": str(row["email"] or row["username"] or "").strip(),
        "username": str(row["username"] or "").strip(),
    }


def resolve_commissioner_user_id(
    owner_user_id: str,
    *,
    commissioner_user_id: Optional[str] = None,
    commissioner_email: Optional[str] = None,
) -> str:
    if commissioner_user_id:
        cid = str(commissioner_user_id).strip()
        with db() as conn:
            row = conn.execute("SELECT id FROM users WHERE id=?", (cid,)).fetchone()
        if not row:
            raise ValueError("commissioner user not found")
        return cid
    if commissioner_email and str(commissioner_email).strip():
        found = lookup_user_by_email(commissioner_email)
        if not found:
            raise ValueError(
                f"No account found for {str(commissioner_email).strip()}. "
                "They must sign in to FND once before you can appoint them commissioner."
            )
        return str(found["user_id"])
    return owner_user_id


def _verify_commish_game_access(league_id: str, user_id: str) -> Dict[str, Any]:
    league_row = _load_league_row(league_id)
    if not league_row:
        raise ValueError("league not found")
    _reject_deleted_league(league_row)
    if str(league_row.get("commissioner_user_id") or "") != user_id:
        raise PermissionError("commissioner only")
    return league_row


def _verify_commish_view_access(league_id: str, user_id: str) -> Tuple[Dict[str, Any], bool]:
    """Commissioner write access, or platform-owner read-only browse."""
    league_row = _load_league_row(league_id)
    if not league_row:
        raise ValueError("league not found")
    _reject_deleted_league(league_row)
    is_commish = str(league_row.get("commissioner_user_id") or "") == user_id
    is_owner = is_platform_owner_user(user_id)
    if not is_commish and not is_owner:
        raise PermissionError("commissioner only")
    return league_row, bool(is_owner and not is_commish)


def _require_commish_write(league_id: str, user_id: str) -> Dict[str, Any]:
    return _verify_commish_game_access(league_id, user_id)


_TEAM_GAMEPLAN_PREF_KEYS = (
    "gameplan_last_confirmed",
    "gameplan_week_to_week",
    "offense_gameplan_library",
    "defense_gameplan_library",
)


def _gameplan_v2_key_belongs_to_team(key: str, team_name: str) -> bool:
    """True when a coach_gameplans_v2 key is for a matchup involving team_name."""
    key = str(key or "").strip()
    team_name = str(team_name or "").strip()
    if not key or not team_name:
        return False
    if key.startswith("bye:week:"):
        parts = key.split(":")
        return len(parts) >= 4 and parts[3] == team_name
    matchup = ""
    if key.startswith("week:"):
        parts = key.split(":", 3)
        matchup = parts[3] if len(parts) > 3 else ""
    elif key.startswith("playoff:"):
        matchup = key.split(":", 1)[1] if ":" in key else ""
    if matchup and " vs " in matchup:
        home, away = matchup.split(" vs ", 1)
        return team_name in (home.strip(), away.strip())
    return False


def _filter_coach_gameplans_v2_for_team(store: Any, team_name: str) -> Dict[str, Any]:
    if not isinstance(store, dict):
        return {}
    team_name = str(team_name or "").strip()
    return {
        k: v
        for k, v in store.items()
        if _gameplan_v2_key_belongs_to_team(str(k), team_name)
    }


def _merge_coach_gameplans_v2_for_team(
    base_store: Any,
    incoming_store: Any,
    team_name: str,
) -> Dict[str, Any]:
    import copy

    merged = copy.deepcopy(base_store) if isinstance(base_store, dict) else {}
    if not isinstance(incoming_store, dict):
        return merged
    team_name = str(team_name or "").strip()
    for key, value in incoming_store.items():
        if _gameplan_v2_key_belongs_to_team(str(key), team_name):
            merged[str(key)] = copy.deepcopy(value)
    return merged


def _persist_team_gameplan_prefs(
    canonical: Dict[str, Any],
    team_name: str,
    incoming: Dict[str, Any],
) -> None:
    import copy

    team_name = str(team_name or "").strip()
    if not team_name or str(incoming.get("user_team") or "") != team_name:
        return
    prefs_root = canonical.get("multiplayer_team_gameplan_prefs")
    if not isinstance(prefs_root, dict):
        prefs_root = {}
    team_prefs = prefs_root.get(team_name)
    if not isinstance(team_prefs, dict):
        team_prefs = {}
    for key in _TEAM_GAMEPLAN_PREF_KEYS:
        if key in incoming:
            team_prefs[key] = copy.deepcopy(incoming[key])
    prefs_root[team_name] = team_prefs
    canonical["multiplayer_team_gameplan_prefs"] = prefs_root
    for key in _TEAM_GAMEPLAN_PREF_KEYS:
        canonical.pop(key, None)


def _sync_team_gameplan_prefs_from_working_state(state: Dict[str, Any], team_name: str) -> None:
    """Persist per-coach gameplan libraries/carry prefs before privacy filtering."""
    import copy

    team_name = str(team_name or "").strip()
    if not team_name or str(state.get("user_team") or "") != team_name:
        return
    prefs_root = state.get("multiplayer_team_gameplan_prefs")
    if not isinstance(prefs_root, dict):
        prefs_root = {}
    team_prefs = prefs_root.get(team_name)
    if not isinstance(team_prefs, dict):
        team_prefs = {}
    for key in _TEAM_GAMEPLAN_PREF_KEYS:
        if key in state:
            team_prefs[key] = copy.deepcopy(state[key])
    prefs_root[team_name] = team_prefs
    state["multiplayer_team_gameplan_prefs"] = prefs_root


def _materialize_mp_carried_gameplans_for_league(state: Dict[str, Any], league_id: str) -> bool:
    """After a league week advances, pre-build carried gameplans for each human coach."""
    import copy

    from backend.services.league_service import _materialize_carried_gameplan_for_current_week

    phase = str(state.get("season_phase") or "").strip().lower()
    if phase not in ("regular", "playoffs"):
        return False
    changed = False
    prefs_root = state.get("multiplayer_team_gameplan_prefs")
    if not isinstance(prefs_root, dict):
        prefs_root = {}
    for member in _human_teams(league_id):
        team = str(member.get("team_name") or "").strip()
        if not team:
            continue
        working = copy.deepcopy(state)
        working["user_team"] = team
        apply_coach_gameplan_privacy_for_team(working, team)
        if _materialize_carried_gameplan_for_current_week(working):
            state["coach_gameplans_v2"] = _merge_coach_gameplans_v2_for_team(
                state.get("coach_gameplans_v2"),
                working.get("coach_gameplans_v2"),
                team,
            )
            changed = True
        _sync_team_gameplan_prefs_from_working_state(working, team)
        wr = working.get("multiplayer_team_gameplan_prefs")
        if isinstance(wr, dict) and isinstance(wr.get(team), dict):
            prefs_root[team] = wr[team]
            changed = True
    if changed:
        state["multiplayer_team_gameplan_prefs"] = prefs_root
        for key in _TEAM_GAMEPLAN_PREF_KEYS:
            state.pop(key, None)
    return changed


def apply_coach_gameplan_privacy_for_team(state: Dict[str, Any], team_name: str) -> Dict[str, Any]:
    """
    Strip other coaches' gameplans from a working copy sent to one human coach.
    Per-coach libraries / carry-forward prefs are hydrated from multiplayer_team_gameplan_prefs.
    """
    import copy

    team_name = str(team_name or "").strip()
    if not team_name:
        return state

    prefs_root = state.get("multiplayer_team_gameplan_prefs")
    if not isinstance(prefs_root, dict):
        prefs_root = {}

    team_prefs = prefs_root.get(team_name)
    if not isinstance(team_prefs, dict):
        team_prefs = {}
    store = state.get("coach_gameplans_v2")
    only_mine = (
        all(_gameplan_v2_key_belongs_to_team(str(k), team_name) for k in store)
        if isinstance(store, dict) and store
        else True
    )
    if only_mine:
        for key in _TEAM_GAMEPLAN_PREF_KEYS:
            if key in state:
                team_prefs[key] = copy.deepcopy(state[key])

    for key in _TEAM_GAMEPLAN_PREF_KEYS:
        if key in team_prefs:
            state[key] = copy.deepcopy(team_prefs[key])
        else:
            state.pop(key, None)

    state["coach_gameplans_v2"] = _filter_coach_gameplans_v2_for_team(
        state.get("coach_gameplans_v2"),
        team_name,
    )
    return state


def _sync_mp_inbox_emails_for_human_teams(
    state: Dict[str, Any],
    league_id: str,
    *,
    completed_week: Optional[int] = None,
    checklist_week: Optional[int] = None,
    playoff_round: bool = False,
) -> None:
    """Generate inbox batches per human coach after commissioner league advance."""
    import copy

    from backend.services.league_service import (
        _coach_sim_emails_enabled,
        _mp_coach_inbox_by_team,
        hydrate_mp_team_inbox_view,
    )
    from systems.coach_email_system import (
        generate_playoff_round_emails,
        generate_week_checklist_email,
        generate_week_sim_emails,
    )

    if not _coach_sim_emails_enabled():
        return
    teams = {str(m["team_name"]) for m in _human_teams(league_id) if m.get("team_name")}
    if not teams:
        return
    for team_name in sorted(teams):
        temp = copy.deepcopy(state)
        temp["user_team"] = team_name
        hydrate_mp_team_inbox_view(temp, team_name)
        if completed_week is not None:
            generate_week_sim_emails(temp, completed_week=int(completed_week))
        if checklist_week is not None:
            generate_week_checklist_email(temp, week=int(checklist_week))
        if playoff_round:
            generate_playoff_round_emails(temp)
        inbox = temp.get("coach_inbox")
        if isinstance(inbox, dict):
            _mp_coach_inbox_by_team(state)[team_name] = copy.deepcopy(inbox)
    state.pop("coach_inbox", None)


def _equipment_item_ids(rows: Any) -> set[str]:
    out: set[str] = set()
    if not isinstance(rows, list):
        return out
    for row in rows:
        if isinstance(row, dict):
            iid = str(row.get("item_id") or row.get("id") or "").strip()
            if iid:
                out.add(iid)
    return out


def _merge_team_program_fields(
    canonical_row: Dict[str, Any],
    incoming_row: Dict[str, Any],
) -> Dict[str, Any]:
    """Keep owned equipment when a stale coach save omits or drops program inventory."""
    import copy

    merged = copy.deepcopy(incoming_row)
    can_eq = canonical_row.get("program_equipment")
    inc_eq = incoming_row.get("program_equipment")
    can_ids = _equipment_item_ids(can_eq)
    inc_ids = _equipment_item_ids(inc_eq)
    if not isinstance(inc_eq, list):
        if isinstance(can_eq, list):
            merged["program_equipment"] = copy.deepcopy(can_eq)
        if incoming_row.get("program_funding_balance") is None and canonical_row.get("program_funding_balance") is not None:
            merged["program_funding_balance"] = canonical_row.get("program_funding_balance")
        if incoming_row.get("program_last_funding_income") is None and canonical_row.get(
            "program_last_funding_income"
        ) is not None:
            merged["program_last_funding_income"] = canonical_row.get("program_last_funding_income")
        return merged
    lost = can_ids - inc_ids
    if lost:
        by_id: Dict[str, Dict[str, Any]] = {}
        if isinstance(can_eq, list):
            for row in can_eq:
                if isinstance(row, dict):
                    iid = str(row.get("item_id") or row.get("id") or "").strip()
                    if iid:
                        by_id[iid] = copy.deepcopy(row)
        for row in inc_eq:
            if isinstance(row, dict):
                iid = str(row.get("item_id") or row.get("id") or "").strip()
                if iid:
                    by_id[iid] = copy.deepcopy(row)
        merged["program_equipment"] = list(by_id.values())
        try:
            can_bal = int(canonical_row.get("program_funding_balance") or 0)
            inc_bal = int(incoming_row.get("program_funding_balance") or 0)
            merged["program_funding_balance"] = min(can_bal, inc_bal)
        except (TypeError, ValueError):
            pass
    return merged


def _merge_coach_state_into_canonical(
    canonical: Dict[str, Any],
    incoming: Dict[str, Any],
    team_name: str,
) -> Dict[str, Any]:
    """Merge a coach working copy into the shared league save without overwriting league calendar."""
    import copy

    out = copy.deepcopy(canonical)
    team_name = str(team_name or "").strip()
    if not team_name:
        raise ValueError("team_name required")

    inc_teams: Dict[str, Dict[str, Any]] = {}
    for row in incoming.get("teams") or []:
        if isinstance(row, dict) and row.get("name"):
            inc_teams[str(row["name"])] = row
    if team_name in inc_teams:
        kept: List[Dict[str, Any]] = []
        replaced = False
        for row in out.get("teams") or []:
            if isinstance(row, dict) and str(row.get("name") or "") == team_name:
                kept.append(_merge_team_program_fields(row, inc_teams[team_name]))
                replaced = True
            elif isinstance(row, dict):
                kept.append(copy.deepcopy(row))
        if not replaced:
            kept.append(copy.deepcopy(inc_teams[team_name]))
        out["teams"] = kept

    inc_gp = incoming.get("coach_gameplans_v2")
    if isinstance(inc_gp, dict) and inc_gp:
        out["coach_gameplans_v2"] = _merge_coach_gameplans_v2_for_team(
            out.get("coach_gameplans_v2"),
            inc_gp,
            team_name,
        )

    _persist_team_gameplan_prefs(out, team_name, incoming)

    if isinstance(incoming.get("coach_inbox"), dict):
        from backend.services.league_service import (
            _mp_coach_inbox_by_team,
            is_multiplayer_league_state,
        )

        if is_multiplayer_league_state(out):
            _mp_coach_inbox_by_team(out)[team_name] = copy.deepcopy(incoming["coach_inbox"])
            out.pop("coach_inbox", None)
        else:
            out["coach_inbox"] = copy.deepcopy(incoming["coach_inbox"])

    if str(incoming.get("user_team") or "") == team_name:
        if isinstance(incoming.get("season_goals"), dict):
            out["season_goals"] = copy.deepcopy(incoming["season_goals"])
        from backend.services.league_service import is_multiplayer_league_state

        if is_multiplayer_league_state(out):
            slice_ = out.get("multiplayer_scrimmage_by_team")
            if not isinstance(slice_, dict):
                slice_ = {}
                out["multiplayer_scrimmage_by_team"] = slice_
            team_slice = slice_.get(team_name)
            if not isinstance(team_slice, dict):
                team_slice = {}
                slice_[team_name] = team_slice
            if "preseason_scrimmage_opponents" in incoming:
                team_slice["opponents"] = copy.deepcopy(incoming["preseason_scrimmage_opponents"])
            if "preseason_scrimmages" in incoming:
                team_slice["scrimmages"] = copy.deepcopy(incoming["preseason_scrimmages"])
            inc_7on7 = incoming.get("offseason_7on7_results")
            if isinstance(inc_7on7, dict):
                by_7 = out.get("multiplayer_7on7_by_team")
                if not isinstance(by_7, dict):
                    by_7 = {}
                    out["multiplayer_7on7_by_team"] = by_7
                team_7 = by_7.get(team_name)
                if not isinstance(team_7, dict):
                    team_7 = {}
                    by_7[team_name] = team_7
                team_7["results"] = copy.deepcopy(inc_7on7)
                if not team_7.get("tier") and inc_7on7.get("tier"):
                    team_7["tier"] = str(inc_7on7.get("tier"))
            inc_themes = incoming.get("home_game_themes")
            if isinstance(inc_themes, dict) and team_name in inc_themes:
                theme_store = out.get("home_game_themes")
                if not isinstance(theme_store, dict):
                    theme_store = {}
                    out["home_game_themes"] = theme_store
                theme_store[team_name] = copy.deepcopy(inc_themes[team_name])
            inc_confirmed = incoming.get("home_game_themes_confirmed_teams")
            if isinstance(inc_confirmed, dict) and team_name in inc_confirmed:
                confirmed_store = out.get("home_game_themes_confirmed_teams")
                if not isinstance(confirmed_store, dict):
                    confirmed_store = {}
                    out["home_game_themes_confirmed_teams"] = confirmed_store
                confirmed_store[team_name] = inc_confirmed[team_name]
            from backend.services.league_service import repair_multiplayer_7on7_storage, repair_multiplayer_scrimmage_storage

            repair_multiplayer_scrimmage_storage(out)
            repair_multiplayer_7on7_storage(out)
        else:
            for key in (
                "preseason_scrimmages",
                "preseason_scrimmage_opponents",
            ):
                if key in incoming:
                    out[key] = copy.deepcopy(incoming[key])

    inc_names = incoming.get("multiplayer_coach_names")
    if isinstance(inc_names, dict):
        names = out.get("multiplayer_coach_names")
        if not isinstance(names, dict):
            names = {}
        names = copy.deepcopy(names)
        if team_name in inc_names:
            names[team_name] = inc_names[team_name]
        out["multiplayer_coach_names"] = names

    if isinstance(incoming.get("offseason_improvements_bank"), dict):
        from backend.services.league_service import (
            _mp_offseason_improvements_bank_by_team,
            is_multiplayer_league_state,
        )

        if is_multiplayer_league_state(out):
            _mp_offseason_improvements_bank_by_team(out)[team_name] = copy.deepcopy(
                incoming["offseason_improvements_bank"]
            )
            out.pop("offseason_improvements_bank", None)
        else:
            out["offseason_improvements_bank"] = copy.deepcopy(incoming["offseason_improvements_bank"])

    if isinstance(incoming.get("offseason_coach_dev_bank"), dict):
        from backend.services.league_service import is_multiplayer_league_state

        if is_multiplayer_league_state(out):
            banks = out.get("offseason_coach_dev_banks")
            if not isinstance(banks, dict):
                banks = {}
            banks = copy.deepcopy(banks)
            banks[team_name] = copy.deepcopy(incoming["offseason_coach_dev_bank"])
            out["offseason_coach_dev_banks"] = banks
            out.pop("offseason_coach_dev_bank", None)
        else:
            out["offseason_coach_dev_bank"] = copy.deepcopy(incoming["offseason_coach_dev_bank"])

    for bank_key in ("offseason_coach_dev_banks",):
        inc_bank = incoming.get(bank_key)
        if isinstance(inc_bank, dict) and team_name in inc_bank:
            base_bank = out.get(bank_key)
            if not isinstance(base_bank, dict):
                base_bank = {}
            base_bank = copy.deepcopy(base_bank)
            base_bank[team_name] = copy.deepcopy(inc_bank[team_name])
            out[bank_key] = base_bank

    inc_picks = incoming.get("cross_region_picks")
    if isinstance(inc_picks, dict) and team_name in inc_picks:
        canon_picks = out.get("cross_region_picks")
        if not isinstance(canon_picks, dict):
            canon_picks = {}
        canon_picks = copy.deepcopy(canon_picks)
        canon_picks[team_name] = copy.deepcopy(inc_picks[team_name])
        out["cross_region_picks"] = canon_picks

    inc_year = incoming.get("program_development_prepared_year")
    if inc_year is not None:
        try:
            out["program_development_prepared_year"] = max(
                int(out.get("program_development_prepared_year") or 0),
                int(inc_year or 0),
            )
        except (TypeError, ValueError):
            pass

    pending_root = out.get("multiplayer_program_dev_pending_by_team")
    if not isinstance(pending_root, dict):
        pending_root = {}
    pending_root = copy.deepcopy(pending_root)
    inc_pending_map = incoming.get("multiplayer_program_dev_pending_by_team")
    if isinstance(inc_pending_map, dict) and team_name in inc_pending_map:
        pending_root[team_name] = copy.deepcopy(inc_pending_map[team_name])
    inc_pending = incoming.get("program_development_pending_actions")
    if isinstance(inc_pending, list):
        pending_root[team_name] = copy.deepcopy(inc_pending)
    if pending_root:
        out["multiplayer_program_dev_pending_by_team"] = pending_root

    out["multiplayer_league"] = True
    mp = out.get("multiplayer") if isinstance(out.get("multiplayer"), dict) else {}
    mp = dict(mp)
    inc_mp = incoming.get("multiplayer") if isinstance(incoming.get("multiplayer"), dict) else {}
    if inc_mp.get("league_id"):
        mp["league_id"] = inc_mp["league_id"]
    mp["multiplayer_league"] = True
    out["multiplayer"] = mp
    return out


def _commissioner_acting_team(league_id: str, user_id: str, state: Dict[str, Any]) -> str:
    with db() as conn:
        row = conn.execute(
            """
            SELECT team_name FROM league_members
            WHERE league_id=? AND user_id=? AND status='active'
            """,
            (league_id, user_id),
        ).fetchone()
    if row and row["team_name"]:
        return str(row["team_name"])
    ut = str(state.get("user_team") or "").strip()
    if ut:
        return ut
    for row in state.get("teams") or []:
        if isinstance(row, dict) and row.get("name"):
            return str(row["name"])
    return ""


def get_league_commish_game_bundle(league_id: str, user_id: str) -> Dict[str, Any]:
    """Load full league save for commissioner to sim/advance the league."""
    import copy

    from systems.league_history import load_league_history
    from systems.save_system import league_history_path, records_path

    league_row = _verify_commish_game_access(league_id, user_id)
    save_dir = str(league_row.get("save_dir") or "")
    from backend.services.league_service import (
        ensure_multiplayer_opening_schedule,
        repair_multiplayer_7on7_storage,
        repair_multiplayer_coach_inbox_storage,
        repair_multiplayer_offseason_training_storage,
        repair_multiplayer_offseason_improvements_storage,
        repair_multiplayer_coach_dev_storage,
        repair_multiplayer_scrimmage_storage,
    )

    canonical = _load_state(save_dir)
    canonical["multiplayer_league"] = True
    mp_meta = canonical.get("multiplayer") if isinstance(canonical.get("multiplayer"), dict) else {}
    mp_meta = dict(mp_meta)
    mp_meta["league_id"] = league_id
    canonical["multiplayer"] = mp_meta
    commish_changed = ensure_multiplayer_opening_schedule(canonical)
    if repair_multiplayer_scrimmage_storage(canonical):
        commish_changed = True
    if repair_multiplayer_7on7_storage(canonical):
        commish_changed = True
    if repair_multiplayer_coach_inbox_storage(canonical):
        commish_changed = True
    if repair_multiplayer_offseason_training_storage(canonical):
        commish_changed = True
    if repair_multiplayer_offseason_improvements_storage(canonical):
        commish_changed = True
    if repair_multiplayer_coach_dev_storage(canonical):
        commish_changed = True
    from backend.services.league_service import _maybe_backfill_mp_offseason_improvements_banks

    if _maybe_backfill_mp_offseason_improvements_banks(canonical, save_dir):
        commish_changed = True
    if commish_changed:
        _save_state(save_dir, canonical)
        with db() as conn:
            conn.execute(
                "UPDATE leagues SET state_version=state_version+1, updated_at=? WHERE id=?",
                (_now(), league_id),
            )

    state = copy.deepcopy(canonical)
    acting = _commissioner_acting_team(league_id, user_id, state)
    if acting:
        state["user_team"] = acting
    state["multiplayer_league"] = True
    state["multiplayer"] = {
        "league_id": league_id,
        "commish_mode": True,
        "team_name": acting or None,
        "multiplayer_league": True,
    }

    from backend.services.league_service import _finalize_cross_region_schedule_state

    _finalize_cross_region_schedule_state(state)

    if acting:
        from backend.services.league_service import (
            _maybe_generate_week_checklist_email,
            hydrate_mp_team_coach_dev_view,
            hydrate_mp_team_improvements_bank_view,
            hydrate_mp_team_inbox_view,
            hydrate_mp_team_offseason_training_view,
        )

        hydrate_mp_team_inbox_view(state, acting)
        hydrate_mp_team_offseason_training_view(state, acting)
        hydrate_mp_team_improvements_bank_view(state, acting)
        hydrate_mp_team_coach_dev_view(state, acting)
        _maybe_generate_week_checklist_email(state)

    league_history: Dict[str, Any] = {"seasons": []}
    records: Dict[str, Any] = {}
    try:
        league_history = load_league_history(league_history_path(save_dir))
    except Exception:
        pass
    try:
        rpath = records_path(save_dir)
        if os.path.isfile(rpath):
            with open_text_with_path_fallback(rpath, "r") as f:
                records = json.load(f)
    except Exception:
        pass

    return {
        "league_id": league_id,
        "commish_mode": True,
        "state": state,
        "league_history": league_history,
        "records": records,
        "state_version": int(league_row.get("state_version") or 0),
    }


def save_league_commish_game_state(
    league_id: str,
    user_id: str,
    state: Dict[str, Any],
) -> Dict[str, Any]:
    """Persist full league save after commissioner sim/advance."""
    import copy

    league_row = _verify_commish_game_access(league_id, user_id)
    save_dir = str(league_row.get("save_dir") or "")
    incoming = copy.deepcopy(state) if isinstance(state, dict) else {}
    mp = incoming.get("multiplayer")
    if not isinstance(mp, dict):
        mp = {}
    mp["league_id"] = league_id
    mp["commish_mode"] = True
    incoming["multiplayer"] = mp
    from backend.services.league_service import (
        persist_mp_team_inbox_slice,
        repair_multiplayer_coach_inbox_storage,
    )

    acting = str(incoming.get("user_team") or mp.get("team_name") or "").strip()
    if acting and isinstance(incoming.get("coach_inbox"), dict):
        persist_mp_team_inbox_slice(incoming, acting)
    repair_multiplayer_coach_inbox_storage(incoming)
    _save_state(save_dir, incoming)
    now = _now()
    with db() as conn:
        conn.execute(
            "UPDATE leagues SET state_version=state_version+1, updated_at=? WHERE id=?",
            (now, league_id),
        )
    return {"ok": True, "state_version": int(league_row.get("state_version") or 0) + 1}


def _verify_team_game_access(league_id: str, user_id: str, team_name: str) -> Dict[str, Any]:
    league_row = _load_league_row(league_id)
    if not league_row:
        raise ValueError("league not found")
    _reject_deleted_league(league_row)
    team_name = str(team_name or "").strip()
    if not team_name:
        raise ValueError("team_name required")
    with db() as conn:
        row = conn.execute(
            """
            SELECT team_name, status, coach_setup_complete FROM league_members
            WHERE league_id=? AND user_id=? AND status='active'
            """,
            (league_id, user_id),
        ).fetchone()
    if not row or str(row["team_name"] or "") != team_name:
        raise PermissionError("not your team")
    if not int(row["coach_setup_complete"] or 0):
        raise PermissionError("coach setup required")
    return league_row


def _unlock_human_playbooks_during_select(state: Dict[str, Any], team_name: str) -> bool:
    """Clear CPU playbook locks so human coaches can choose schemes in Playbook Select."""
    phase = str(state.get("season_phase") or "").strip().lower()
    if phase != "preseason":
        return False
    stages = state.get("preseason_stages") or []
    idx = int(state.get("preseason_stage_index") or 0)
    if not isinstance(stages, list) or idx < 0 or idx >= len(stages):
        return False
    if str(stages[idx]) != "Playbook Select":
        return False
    team_name = str(team_name or "").strip()
    if not team_name:
        return False
    for row in state.get("teams") or []:
        if not isinstance(row, dict) or str(row.get("name") or "") != team_name:
            continue
        coach = row.get("coach") if isinstance(row.get("coach"), dict) else None
        if not coach:
            return False
        last = int(coach.get("last_preferred_playbook_change_year") or 0)
        if last <= 0:
            return False
        coach["last_preferred_playbook_change_year"] = 0
        row["coach"] = coach
        return True
    return False


def get_league_game_bundle(league_id: str, user_id: str, team_name: str) -> Dict[str, Any]:
    """Load league save scoped to the coach's team (same shape as GET /saves/{id})."""
    import copy

    from systems.league_history import load_league_history
    from systems.save_system import league_history_path, records_path

    league_row = _verify_team_game_access(league_id, user_id, team_name)
    save_dir = str(league_row.get("save_dir") or "")
    from backend.services.league_service import (
        PRESEASON_STAGES,
        _ensure_mp_team_scrimmage_opponents,
        _maybe_generate_week_checklist_email,
        ensure_multiplayer_opening_schedule,
        hydrate_mp_team_inbox_view,
        hydrate_mp_team_coach_dev_view,
        hydrate_mp_team_improvements_bank_view,
        hydrate_mp_team_offseason_training_view,
        hydrate_mp_team_scrimmage_view,
        hydrate_mp_team_7on7_view,
        is_multiplayer_league_state,
        persist_mp_team_scrimmage_slice,
        repair_multiplayer_7on7_storage,
        repair_multiplayer_coach_inbox_storage,
        repair_multiplayer_offseason_training_storage,
        repair_multiplayer_offseason_improvements_storage,
        repair_multiplayer_coach_dev_storage,
        repair_multiplayer_scrimmage_storage,
    )

    canonical = _load_state(save_dir)
    canonical["multiplayer_league"] = True
    mp_meta = canonical.get("multiplayer") if isinstance(canonical.get("multiplayer"), dict) else {}
    mp_meta = dict(mp_meta)
    mp_meta["league_id"] = league_id
    canonical["multiplayer"] = mp_meta
    changed = ensure_multiplayer_opening_schedule(canonical)
    if repair_multiplayer_scrimmage_storage(canonical):
        changed = True
    if repair_multiplayer_7on7_storage(canonical):
        changed = True
    if repair_multiplayer_coach_inbox_storage(canonical):
        changed = True
    if repair_multiplayer_offseason_training_storage(canonical):
        changed = True
    if repair_multiplayer_offseason_improvements_storage(canonical):
        changed = True
    if repair_multiplayer_coach_dev_storage(canonical):
        changed = True
    from backend.services.league_service import _maybe_backfill_mp_offseason_improvements_banks

    if _maybe_backfill_mp_offseason_improvements_banks(canonical, save_dir):
        changed = True
    if _unlock_human_playbooks_during_select(canonical, team_name):
        changed = True
    if changed:
        _save_state(save_dir, canonical)
        with db() as conn:
            conn.execute(
                "UPDATE leagues SET state_version=state_version+1, updated_at=? WHERE id=?",
                (_now(), league_id),
            )

    state = copy.deepcopy(canonical)
    state["user_team"] = team_name
    mp_names = state.get("multiplayer_coach_names")
    if isinstance(mp_names, dict) and mp_names.get(team_name):
        state["user_coach_name"] = str(mp_names[team_name])
    else:
        for row in state.get("teams") or []:
            if isinstance(row, dict) and str(row.get("name") or "") == team_name:
                coach = row.get("coach") if isinstance(row.get("coach"), dict) else {}
                nm = str(coach.get("name") or "").strip()
                if nm:
                    state["user_coach_name"] = nm
                break
    state["multiplayer"] = {"league_id": league_id, "team_name": team_name, "multiplayer_league": True}
    state["multiplayer_league"] = True

    from backend.services.league_service import _finalize_cross_region_schedule_state

    _finalize_cross_region_schedule_state(state)

    hydrate_mp_team_scrimmage_view(state, team_name)
    hydrate_mp_team_7on7_view(state, team_name)
    hydrate_mp_team_inbox_view(state, team_name)
    hydrate_mp_team_offseason_training_view(state, team_name)
    hydrate_mp_team_improvements_bank_view(state, team_name)
    hydrate_mp_team_coach_dev_view(state, team_name)
    inbox_before = len((state.get("coach_inbox") or {}).get("emails") or [])
    _maybe_generate_week_checklist_email(state)
    inbox_after = len((state.get("coach_inbox") or {}).get("emails") or [])
    if inbox_after > inbox_before:
        from backend.services.league_service import _mp_coach_inbox_by_team

        merged = copy.deepcopy(canonical)
        _mp_coach_inbox_by_team(merged)[team_name] = copy.deepcopy(state.get("coach_inbox") or {})
        repair_multiplayer_coach_inbox_storage(merged)
        _save_state(save_dir, merged)
        canonical = merged
        with db() as conn:
            conn.execute(
                "UPDATE leagues SET state_version=state_version+1, updated_at=? WHERE id=?",
                (_now(), league_id),
            )
    confirmed_teams = state.get("home_game_themes_confirmed_teams")
    if isinstance(confirmed_teams, dict):
        state["home_game_themes_user_confirmed"] = bool(confirmed_teams.get(team_name))
    else:
        state["home_game_themes_user_confirmed"] = False
    if is_multiplayer_league_state(state):
        phase = str(state.get("season_phase") or "").strip().lower()
        if phase == "preseason":
            stages = state.get("preseason_stages") or list(PRESEASON_STAGES)
            idx = int(state.get("preseason_stage_index", 0))
            if idx < len(stages) and stages[idx] in ("Scrimmage 1", "Scrimmage 2"):
                team_names = [
                    str(t.get("name") or "")
                    for t in (state.get("teams") or [])
                    if isinstance(t, dict) and t.get("name")
                ]
                if _ensure_mp_team_scrimmage_opponents(state, team_name, team_names):
                    merged = copy.deepcopy(canonical)
                    persist_mp_team_scrimmage_slice(state, team_name)
                    persist_mp_team_scrimmage_slice(merged, team_name)
                    merged["multiplayer_league"] = True
                    mp_meta2 = merged.get("multiplayer") if isinstance(merged.get("multiplayer"), dict) else {}
                    mp_meta2 = dict(mp_meta2)
                    mp_meta2["league_id"] = league_id
                    merged["multiplayer"] = mp_meta2
                    _save_state(save_dir, merged)
                    canonical = merged
                    with db() as conn:
                        conn.execute(
                            "UPDATE leagues SET state_version=state_version+1, updated_at=? WHERE id=?",
                            (_now(), league_id),
                        )

    apply_coach_gameplan_privacy_for_team(state, team_name)
    from backend.services.league_service import _materialize_carried_gameplan_for_current_week

    materialized = _materialize_carried_gameplan_for_current_week(state)
    if materialized:
        _sync_team_gameplan_prefs_from_working_state(state, team_name)
        merged = _merge_coach_state_into_canonical(canonical, state, team_name)
        _save_state(save_dir, merged)
        canonical = merged
        with db() as conn:
            conn.execute(
                "UPDATE leagues SET state_version=state_version+1, updated_at=? WHERE id=?",
                (_now(), league_id),
            )
        state = copy.deepcopy(merged)
        state["user_team"] = team_name
        state["multiplayer"] = {"league_id": league_id, "team_name": team_name, "multiplayer_league": True}
        state["multiplayer_league"] = True
        apply_coach_gameplan_privacy_for_team(state, team_name)

    league_history: Dict[str, Any] = {"seasons": []}
    records: Dict[str, Any] = {}
    try:
        league_history = load_league_history(league_history_path(save_dir))
    except Exception:
        pass
    try:
        rpath = records_path(save_dir)
        if os.path.isfile(rpath):
            with open_text_with_path_fallback(rpath, "r") as f:
                records = json.load(f)
    except Exception:
        pass

    return {
        "league_id": league_id,
        "team_name": team_name,
        "state": state,
        "league_history": league_history,
        "records": records,
        "state_version": int(league_row.get("state_version") or 0),
    }


def save_league_game_state(
    league_id: str,
    user_id: str,
    team_name: str,
    state: Dict[str, Any],
) -> Dict[str, Any]:
    """Persist coach's working copy of the shared league save."""
    import copy

    league_row = _verify_team_game_access(league_id, user_id, team_name)
    save_dir = str(league_row.get("save_dir") or "")
    incoming = copy.deepcopy(state) if isinstance(state, dict) else {}
    incoming["user_team"] = team_name
    from backend.services.league_service import (
        persist_mp_team_coach_dev_slice,
        persist_mp_team_improvements_bank_slice,
        persist_mp_team_inbox_slice,
    )

    persist_mp_team_inbox_slice(incoming, team_name)
    persist_mp_team_improvements_bank_slice(incoming, team_name)
    persist_mp_team_coach_dev_slice(incoming, team_name)
    _sync_team_gameplan_prefs_from_working_state(incoming, team_name)
    apply_coach_gameplan_privacy_for_team(incoming, team_name)
    canonical = _load_state(save_dir)
    merged = _merge_coach_state_into_canonical(canonical, incoming, team_name)
    merged["user_team"] = team_name
    mp = merged.get("multiplayer")
    if not isinstance(mp, dict):
        mp = {}
    mp["league_id"] = league_id
    mp["team_name"] = team_name
    merged["multiplayer"] = mp
    _save_state(save_dir, merged)
    now = _now()
    with db() as conn:
        conn.execute(
            "UPDATE leagues SET state_version=state_version+1, updated_at=? WHERE id=?",
            (now, league_id),
        )
    return {"ok": True, "state_version": int(league_row.get("state_version") or 0) + 1}


def _teams_meta_from_state(state: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for row in state.get("teams") or []:
        if isinstance(row, dict) and row.get("name"):
            out[str(row["name"])] = row
    return out


def league_schools_for_user(league_id: str, user_id: str) -> List[Dict[str, Any]]:
    """Team list from league save (for coach setup school picker / prestige)."""
    league_row = _load_league_row(league_id)
    if not league_row:
        raise ValueError("league not found")
    with db() as conn:
        mem = conn.execute(
            """
            SELECT 1 FROM league_members
            WHERE league_id=? AND user_id=? AND status != 'removed'
            """,
            (league_id, user_id),
        ).fetchone()
    if not mem and not is_platform_owner_user(user_id):
        raise PermissionError("not a league member")
    save_dir = str(league_row.get("save_dir") or "")
    state = _load_state(save_dir)
    schools: List[Dict[str, Any]] = []
    for row in state.get("teams") or []:
        if not isinstance(row, dict) or not row.get("name"):
            continue
        schools.append(
            {
                "name": row.get("name"),
                "prestige": row.get("prestige"),
                "classification": row.get("classification"),
                "region": row.get("region"),
            }
        )
    schools.sort(key=lambda s: str(s.get("name") or "").lower())
    return schools


def _league_timezone(league_row: Dict[str, Any]) -> ZoneInfo:
    from datetime import timezone as dt_timezone

    tz_name = str(league_row.get("timezone") or "America/New_York")
    for candidate in (tz_name, "America/New_York"):
        try:
            return ZoneInfo(candidate)
        except Exception:
            continue
    # Windows/local envs without tzdata — UTC is good enough for interval math.
    return dt_timezone.utc  # type: ignore[return-value]


_ALLOWED_ADVANCE_INTERVAL_HOURS = frozenset({12, 24})


def _normalize_advance_interval_hours(raw: Any) -> Optional[int]:
    """Return 12/24 for interval mode, or None for weekly day+time mode."""
    if raw is None or raw == "":
        return None
    try:
        hours = int(raw)
    except (TypeError, ValueError):
        raise ValueError("advance_interval_hours must be 12 or 24") from None
    if hours not in _ALLOWED_ADVANCE_INTERVAL_HOURS:
        raise ValueError("advance_interval_hours must be 12 or 24")
    return hours


def _advance_interval_hours(league_row: Dict[str, Any]) -> Optional[int]:
    try:
        return _normalize_advance_interval_hours(league_row.get("advance_interval_hours"))
    except ValueError:
        return None


def _interval_cycle_base_ts(league_row: Dict[str, Any]) -> Optional[int]:
    """Unix timestamp of last advance, or cycle start when interval mode was enabled."""
    last_at = int(league_row.get("last_auto_advance_at") or 0)
    if last_at > 0:
        return last_at
    anchor = int(league_row.get("advance_cycle_anchor_at") or 0)
    return anchor if anchor > 0 else None


def _next_interval_deadline(league_row: Dict[str, Any]) -> Optional[datetime]:
    hours = _advance_interval_hours(league_row)
    if not hours:
        return None
    base = _interval_cycle_base_ts(league_row)
    if not base:
        return None
    tz = _league_timezone(league_row)
    return datetime.fromtimestamp(base, tz) + timedelta(hours=hours)


def _advance_countdown_iso(league_row: Dict[str, Any]) -> Optional[str]:
    if str(league_row.get("advance_mode") or "manual").lower() != "auto":
        return None
    if _advance_interval_hours(league_row):
        deadline = _next_interval_deadline(league_row)
        return deadline.isoformat() if deadline else None
    tz = _league_timezone(league_row)
    dow = league_row.get("advance_deadline_dow")
    time_local = str(league_row.get("advance_deadline_time_local") or "23:59").strip()
    if dow is None:
        return None
    try:
        hour, minute = [int(x) for x in time_local.split(":", 1)]
    except Exception:
        hour, minute = 23, 59
    now = datetime.now(tz)
    target_dow = int(dow) % 7
    days_ahead = (target_dow - now.weekday()) % 7
    candidate = now.replace(hour=hour, minute=minute, second=0, microsecond=0) + timedelta(days=days_ahead)
    if candidate <= now:
        candidate += timedelta(days=7)
    return candidate.isoformat()


def _format_countdown(deadline_iso: Optional[str]) -> Optional[str]:
    if not deadline_iso:
        return None
    try:
        deadline = datetime.fromisoformat(deadline_iso)
        if deadline.tzinfo is None:
            deadline = deadline.replace(tzinfo=ZoneInfo("UTC"))
        now = datetime.now(deadline.tzinfo)
        delta = deadline - now
        if delta.total_seconds() <= 0:
            return "Due now"
        days = delta.days
        hours, rem = divmod(int(delta.total_seconds()) - days * 86400, 3600)
        minutes = rem // 60
        if days > 0:
            return f"{days}d {hours}h {minutes}m"
        if hours > 0:
            return f"{hours}h {minutes}m"
        return f"{minutes}m"
    except Exception:
        return None


def _most_recent_advance_deadline(league_row: Dict[str, Any]) -> Optional[datetime]:
    """Most recent scheduled auto-advance instant (may be in the past). Weekly mode only."""
    if str(league_row.get("advance_mode") or "manual").lower() != "auto":
        return None
    if _advance_interval_hours(league_row):
        return None
    dow = league_row.get("advance_deadline_dow")
    if dow is None:
        return None
    tz = _league_timezone(league_row)
    time_local = str(league_row.get("advance_deadline_time_local") or "23:59").strip()
    try:
        hour, minute = [int(x) for x in time_local.split(":", 1)]
    except Exception:
        hour, minute = 23, 59
    now = datetime.now(tz)
    target_dow = int(dow) % 7
    days_back = (now.weekday() - target_dow) % 7
    candidate = now.replace(hour=hour, minute=minute, second=0, microsecond=0) - timedelta(days=days_back)
    if candidate > now:
        candidate -= timedelta(days=7)
    return candidate


def try_auto_advance_league(league_id: str) -> bool:
    """If auto-advance deadline passed, advance once as commissioner."""
    league_row = _load_league_row(league_id)
    if not league_row:
        return False
    if str(league_row.get("advance_mode") or "manual").lower() != "auto":
        return False

    hours = _advance_interval_hours(league_row)
    if hours:
        deadline = _next_interval_deadline(league_row)
        if deadline is None:
            return False
        now = datetime.now(deadline.tzinfo)
        if now < deadline:
            return False
    else:
        deadline = _most_recent_advance_deadline(league_row)
        if deadline is None:
            return False
        now = datetime.now(deadline.tzinfo)
        if now < deadline:
            return False
        last_at = int(league_row.get("last_auto_advance_at") or 0)
        if last_at >= int(deadline.timestamp()):
            return False

    commish_id = str(league_row.get("commissioner_user_id") or "")
    if not commish_id:
        return False
    try:
        commish_advance_league(league_id, commish_id, advance_source="auto")
    except Exception:
        return False
    with db() as conn:
        conn.execute(
            "UPDATE leagues SET last_auto_advance_at=?, updated_at=? WHERE id=?",
            (int(now.timestamp()), _now(), league_id),
        )
    return True


def run_auto_advance_for_league_ids(league_ids: List[str]) -> None:
    for league_id in league_ids:
        try:
            try_auto_advance_league(league_id)
        except Exception:
            continue


def vacate_team_member(league_id: str, actor_user_id: str, target_user_id: str) -> Dict[str, Any]:
    _require_commish_write(league_id, actor_user_id)
    with db() as conn:
        row = conn.execute(
            """
            SELECT team_name FROM league_members
            WHERE league_id=? AND user_id=? AND status='active' AND team_name IS NOT NULL
            """,
            (league_id, target_user_id),
        ).fetchone()
        if not row or not row["team_name"]:
            raise ValueError("member has no team to vacate")
        team_name = str(row["team_name"])
        conn.execute(
            """
            UPDATE league_members
            SET team_name=NULL, status='unassigned', pin_hash=NULL, pin_updated_at=NULL,
                coach_setup_complete=0, control_mode='human'
            WHERE league_id=? AND user_id=?
            """,
            (league_id, target_user_id),
        )
        conn.execute(
            "DELETE FROM league_submit_status WHERE league_id=? AND user_id=?",
            (league_id, target_user_id),
        )
    now = _now()
    with db() as conn:
        conn.execute(
            """
            INSERT INTO league_activity_log (id, league_id, actor_user_id, action, detail_json, created_at)
            VALUES (?,?,?,?,?,?)
            """,
            (
                str(uuid.uuid4()),
                league_id,
                actor_user_id,
                "vacate_team",
                json.dumps({"text": f"Vacated {team_name}", "icon": "🚪"}),
                now,
            ),
        )
    return {"ok": True, "team_name": team_name, "user_id": target_user_id}


def remove_league_member(league_id: str, actor_user_id: str, target_user_id: str) -> Dict[str, Any]:
    league_row = _require_commish_write(league_id, actor_user_id)
    if str(league_row.get("commissioner_user_id") or "") == target_user_id:
        raise ValueError("cannot remove the commissioner")
    with db() as conn:
        row = conn.execute(
            """
            SELECT m.team_name, u.email, u.username FROM league_members m
            LEFT JOIN users u ON u.id = m.user_id
            WHERE m.league_id=? AND m.user_id=? AND m.status != 'removed'
            """,
            (league_id, target_user_id),
        ).fetchone()
        if not row:
            raise ValueError("member not found")
        conn.execute(
            """
            UPDATE league_members
            SET status='removed', team_name=NULL, pin_hash=NULL, pin_updated_at=NULL
            WHERE league_id=? AND user_id=?
            """,
            (league_id, target_user_id),
        )
        conn.execute(
            "DELETE FROM league_submit_status WHERE league_id=? AND user_id=?",
            (league_id, target_user_id),
        )
    label = str(row["team_name"] or row["email"] or row["username"] or target_user_id)
    now = _now()
    with db() as conn:
        conn.execute(
            """
            INSERT INTO league_activity_log (id, league_id, actor_user_id, action, detail_json, created_at)
            VALUES (?,?,?,?,?,?)
            """,
            (
                str(uuid.uuid4()),
                league_id,
                actor_user_id,
                "remove_member",
                json.dumps({"text": f"Removed {label}", "icon": "✖"}),
                now,
            ),
        )
    return {"ok": True, "user_id": target_user_id}


def revoke_league_invite(league_id: str, actor_user_id: str, invite_id: str) -> Dict[str, Any]:
    _require_commish_write(league_id, actor_user_id)
    with db() as conn:
        row = conn.execute(
            "SELECT email FROM league_invites WHERE id=? AND league_id=? AND status='pending'",
            (invite_id, league_id),
        ).fetchone()
        if not row:
            raise ValueError("pending invite not found")
        conn.execute(
            "UPDATE league_invites SET status='revoked' WHERE id=? AND league_id=?",
            (invite_id, league_id),
        )
    return {"ok": True, "invite_id": invite_id, "email": str(row["email"])}


def list_leagues_for_user(user_id: str) -> List[Dict[str, Any]]:
    is_owner = is_platform_owner_user(user_id)
    with db() as conn:
        if is_owner:
            rows = conn.execute(
                """
                SELECT id, name, status, commissioner_user_id, updated_at, save_dir
                FROM leagues
                WHERE status != 'deleted'
                ORDER BY updated_at DESC
                """
            ).fetchall()
        else:
            rows = conn.execute(
                """
                SELECT DISTINCT l.id, l.name, l.status, l.commissioner_user_id, l.updated_at, l.save_dir
                FROM leagues l
                INNER JOIN league_members m ON m.league_id = l.id
                WHERE m.user_id = ? AND m.status != 'removed' AND l.status != 'deleted'
                ORDER BY l.updated_at DESC
                """,
                (user_id,),
            ).fetchall()
        row_payloads: List[Dict[str, Any]] = []
        for r in rows:
            league_id = r["id"]
            mem_rows = conn.execute(
                """
                SELECT team_name, role, status, control_mode, coach_setup_complete
                FROM league_members
                WHERE league_id=? AND user_id=? AND status != 'removed'
                """,
                (league_id, user_id),
            ).fetchall()
            is_commish = str(r["commissioner_user_id"] or "") == user_id or any(
                str(m["role"] or "") == "commissioner" for m in mem_rows
            )
            if is_owner and not mem_rows:
                is_commish = True
            teams = [
                {
                    "team_name": m["team_name"],
                    "status": m["status"],
                    "control_mode": m["control_mode"],
                    "role": m["role"],
                    "coach_setup_complete": bool(m["coach_setup_complete"]),
                }
                for m in mem_rows
                if m["team_name"]
            ]
            unassigned = any(not m["team_name"] for m in mem_rows)
            row_payloads.append(
                {
                    "league_id": league_id,
                    "name": r["name"],
                    "status": r["status"],
                    "is_commissioner": is_commish,
                    "is_platform_owner_view": is_owner,
                    "can_run_league": str(r["commissioner_user_id"] or "") == user_id,
                    "teams": teams,
                    "unassigned": unassigned,
                    "save_dir": str(r["save_dir"] or ""),
                    "updated_at": int(r["updated_at"]),
                }
            )

    out: List[Dict[str, Any]] = []
    for item in row_payloads:
        badges: List[str] = []
        teams = item["teams"]
        if item["is_platform_owner_view"] and not item["can_run_league"]:
            badges.append("Admin")
        if item["is_commissioner"]:
            badges.append("Commissioner")
        submitted = False
        your_turn = False
        week_label = None
        if teams:
            if any(not t.get("coach_setup_complete") for t in teams):
                badges.append("Setup needed")
        elif item.get("unassigned"):
            badges.append("Awaiting team")
        out.append(
            {
                "league_id": item["league_id"],
                "name": item["name"],
                "status": item["status"],
                "is_commissioner": item["is_commissioner"],
                "is_platform_owner_view": item["is_platform_owner_view"],
                "can_run_league": item["can_run_league"],
                "teams": teams,
                "unassigned": bool(item.get("unassigned")),
                "updated_at": item["updated_at"],
                "badges": badges,
                "submitted": submitted,
                "your_turn": your_turn,
                "week_label": week_label,
            }
        )
    return out


def verify_team_pin(league_id: str, user_id: str, team_name: str, pin: str) -> bool:
    with db() as conn:
        row = conn.execute(
            """
            SELECT pin_hash FROM league_members
            WHERE league_id=? AND user_id=? AND team_name=? AND status='active'
            """,
            (league_id, user_id, team_name),
        ).fetchone()
    if not row or not row["pin_hash"]:
        return False
    return row["pin_hash"] == _hash_pin(pin)


def _submitted_teams(league_id: str, stage_key: str) -> set[str]:
    with db() as conn:
        rows = conn.execute(
            "SELECT team_name FROM league_submit_status WHERE league_id=? AND stage_key=?",
            (league_id, stage_key),
        ).fetchall()
    return {str(r["team_name"]) for r in rows if r["team_name"]}


def _human_teams(league_id: str) -> List[Dict[str, Any]]:
    with db() as conn:
        rows = conn.execute(
            """
            SELECT team_name, control_mode, status, user_id
            FROM league_members
            WHERE league_id=? AND status='active' AND team_name IS NOT NULL AND control_mode='human'
            """,
            (league_id,),
        ).fetchall()
    return [dict(r) for r in rows]


def build_league_dashboard(
    league_id: str,
    user_id: str,
    *,
    acting_team_name: Optional[str] = None,
) -> Dict[str, Any]:
    league_row = _load_league_row(league_id)
    if not league_row:
        raise ValueError("league not found")

    is_owner = is_platform_owner_user(user_id)
    is_commish = str(league_row.get("commissioner_user_id") or "") == user_id
    if is_commish:
        try_auto_advance_league(league_id)
        league_row = _load_league_row(league_id) or league_row
    if not is_commish and not is_owner:
        with db() as conn:
            row = conn.execute(
                """
                SELECT 1 FROM league_members
                WHERE league_id=? AND user_id=? AND status != 'removed'
                LIMIT 1
                """,
                (league_id, user_id),
            ).fetchone()
        if not row:
            raise ValueError("not a league member")

    state = _load_state(str(league_row["save_dir"]))
    teams_meta = _teams_meta_from_state(state)
    standings = state.get("standings") if isinstance(state.get("standings"), dict) else {}
    stage_key = _stage_key_from_state(state)
    submitted = _submitted_teams(league_id, stage_key)
    human_members = _human_teams(league_id)

    # Divisions
    divisions: Dict[str, List[str]] = {}
    for name, meta in teams_meta.items():
        key = _division_key(meta)
        divisions.setdefault(key, []).append(name)
    for names in divisions.values():
        names.sort(key=lambda n: (-int((standings.get(n) or {}).get("wins", 0) or 0), n))

    division_count = len(divisions)
    team_count = len(teams_meta)

    # Week info
    phase = str(state.get("season_phase") or "regular").strip().lower()
    current_week = int(state.get("current_week", 1) or 1)
    weeks = state.get("weeks") or []
    total_weeks = len(weeks) if isinstance(weeks, list) and weeks else 12
    week_label = f"Week {current_week} of {total_weeks}"
    if phase == "preseason":
        stages = state.get("preseason_stages") or []
        idx = int(state.get("preseason_stage_index", 0) or 0)
        week_label = f"Preseason — {stages[idx] if idx < len(stages) else 'Complete'}"
    elif phase == "offseason":
        stages = state.get("offseason_stages") or []
        idx = int(state.get("offseason_stage_index", 0) or 0)
        week_label = f"Offseason — {stages[idx] if idx < len(stages) else 'Complete'}"
    elif phase == "playoffs":
        week_label = "Playoffs"

    # Submission progress — human teams + auto/cpu count as submitted for progress
    human_team_names = {str(m["team_name"]) for m in human_members}
    submitted_humans = len([t for t in human_team_names if t in submitted])
    auto_teams = {
        str(m["team_name"])
        for m in human_members
        if str(m.get("control_mode") or "") == "auto" and m.get("team_name")
    }
    with db() as conn:
        auto_rows = conn.execute(
            """
            SELECT team_name FROM league_members
            WHERE league_id=? AND status='active' AND control_mode IN ('auto', 'cpu', 'vacant') AND team_name IS NOT NULL
            """,
            (league_id,),
        ).fetchall()
    cpu_submitted_count = len(auto_rows) + len(auto_teams)
    accountable = len(human_team_names) + len(auto_rows)
    submitted_total = submitted_humans + len(auto_rows) + len([t for t in auto_teams if t not in submitted])
    submitted_total = min(accountable if accountable else team_count, submitted_humans + len(auto_rows))
    progress_denominator = accountable if accountable else team_count
    progress_pct = int(round(100 * submitted_total / progress_denominator)) if progress_denominator else 0

    division_submissions = []
    for div_name, team_names in sorted(divisions.items()):
        div_humans = [t for t in team_names if t in human_team_names]
        div_submitted = [t for t in team_names if t in submitted or t not in human_team_names]
        division_submissions.append(
            {
                "division": div_name,
                "submitted_count": len(div_submitted),
                "total_count": len(team_names),
                "teams": [
                    {
                        "name": t,
                        "submitted": t in submitted or t not in human_team_names,
                        "is_human": t in human_team_names,
                    }
                    for t in team_names
                ],
            }
        )

    acting = acting_team_name or None
    your_submitted = acting in submitted if acting else False
    unsubmit_locked = _is_unsubmit_locked(league_row)
    your_status = {
        "submitted": your_submitted,
        "can_unsubmit": your_submitted and not unsubmit_locked,
        "label": "You're submitted" if your_submitted else "Not submitted yet",
        "sub_label": (
            f"Locked for {week_label}"
            if your_submitted and unsubmit_locked
            else (f"Locked for {week_label}" if your_submitted else f"Complete prep for {week_label}")
        ),
    }

    # Featured game
    featured_game = None
    if acting and phase == "regular" and weeks:
        wk_idx = max(0, current_week - 1)
        if wk_idx < len(weeks):
            for g in weeks[wk_idx] or []:
                if not isinstance(g, dict):
                    continue
                home = str(g.get("home") or "")
                away = str(g.get("away") or "")
                if acting not in (home, away):
                    continue
                is_home = acting == home
                opp = away if is_home else home
                featured_game = {
                    "week": current_week,
                    "your_team": acting,
                    "opponent": opp,
                    "is_home": is_home,
                    "your_record": _record_label(teams_meta.get(acting, {"name": acting}), standings),
                    "opponent_record": _record_label(teams_meta.get(opp, {"name": opp}), standings),
                    "your_initials": _team_initials(acting),
                    "opponent_initials": _team_initials(opp),
                    "division": _division_key(teams_meta.get(acting, {})),
                    "tags": [],
                }
                rivals = teams_meta.get(acting, {}).get("rivals") or []
                if isinstance(rivals, list) and opp in rivals:
                    featured_game["tags"].append("Rivalry")
                break

    # Full slate
    slate_games: List[Dict[str, Any]] = []
    if phase == "regular" and weeks:
        wk_idx = max(0, current_week - 1)
        if wk_idx < len(weeks):
            for g in weeks[wk_idx] or []:
                if not isinstance(g, dict):
                    continue
                home = str(g.get("home") or "")
                away = str(g.get("away") or "")
                if not home or not away:
                    continue
                div = _division_key(teams_meta.get(home, {}))
                notable = False
                tags: List[str] = []
                rh = teams_meta.get(home, {}).get("rivals") or []
                if isinstance(rh, list) and away in rh:
                    notable = True
                    tags.append("Rivalry")
                hw = int((standings.get(home) or {}).get("wins", 0) or 0)
                aw = int((standings.get(away) or {}).get("wins", 0) or 0)
                if hw >= 5 and aw >= 5:
                    notable = True
                    tags.append("Top teams")
                slate_games.append(
                    {
                        "home": home,
                        "away": away,
                        "home_initials": _team_initials(home),
                        "away_initials": _team_initials(away),
                        "division": div,
                        "notable": notable,
                        "tags": tags,
                    }
                )

    # Standings by division
    standings_by_division = []
    for div_name, team_names in sorted(divisions.items()):
        rows = []
        for i, tname in enumerate(team_names, start=1):
            rows.append(
                {
                    "rank": i,
                    "team": tname,
                    "record": _record_label(teams_meta.get(tname, {"name": tname}), standings),
                    "is_you": tname == acting,
                }
            )
        standings_by_division.append({"division": div_name, "rows": rows})

    full_league_standings = []
    sorted_teams = sorted(
        teams_meta.keys(),
        key=lambda n: (
            -int((standings.get(n) or {}).get("wins", 0) or 0),
            int((standings.get(n) or {}).get("losses", 0) or 0),
            n,
        ),
    )
    for i, tname in enumerate(sorted_teams, start=1):
        full_league_standings.append(
            {
                "rank": i,
                "team": tname,
                "record": _record_label(teams_meta.get(tname, {"name": tname}), standings),
                "division": _division_key(teams_meta.get(tname, {})),
                "is_you": tname == acting,
            }
        )

    # Activity: coach actions (submit/invite/etc.) first, then recent results
    activity: List[Dict[str, Any]] = []
    with db() as conn:
        log_rows = conn.execute(
            """
            SELECT action, detail_json, created_at FROM league_activity_log
            WHERE league_id=? ORDER BY created_at DESC LIMIT 12
            """,
            (league_id,),
        ).fetchall()
    for lr in log_rows:
        detail = {}
        try:
            detail = json.loads(lr["detail_json"] or "{}")
        except Exception:
            pass
        activity.append(
            {
                "icon": str(detail.get("icon") or "📋"),
                "text": str(detail.get("text") or lr["action"]),
                "time_label": _activity_time_label(int(lr["created_at"] or 0)),
                "created_at": int(lr["created_at"] or 0),
            }
        )

    week_results = state.get("week_results") or []
    if current_week > 1 and isinstance(week_results, list):
        prev_idx = current_week - 2
        if 0 <= prev_idx < len(week_results):
            for gi, g in enumerate(weeks[prev_idx] if prev_idx < len(weeks) else []):
                if gi >= len(week_results[prev_idx]):
                    break
                slot = week_results[prev_idx][gi]
                if not isinstance(slot, dict) or not slot.get("played"):
                    continue
                home = str(g.get("home") or "")
                away = str(g.get("away") or "")
                hs = int(slot.get("home_score", 0) or 0)
                aws = int(slot.get("away_score", 0) or 0)
                if hs == aws:
                    continue
                winner = home if hs > aws else away
                loser = away if hs > aws else home
                wscore = max(hs, aws)
                lscore = min(hs, aws)
                activity.append(
                    {
                        "icon": "🏈",
                        "text": f"{winner} defeated {loser} {wscore}–{lscore}",
                        "time_label": f"Week {current_week - 1}",
                        "created_at": 0,
                    }
                )
    activity = activity[:12]

    chat_messages = list_league_chat_messages(league_id, user_id, limit=40)

    deadline_iso = _advance_countdown_iso(league_row)
    league_name = str(league_row.get("name") or "League")
    crest = "".join(p[0] for p in league_name.split()[:2]).upper()[:2] or "LG"

    return {
        "league_id": league_id,
        "league_name": league_name,
        "league_crest": crest,
        "league_subtitle": f"{team_count} Teams · {division_count} Divisions",
        "week_label": week_label,
        "season_phase": phase,
        "stage_key": stage_key,
        "countdown_label": "Advances in" if deadline_iso else None,
        "countdown_value": _format_countdown(deadline_iso),
        "advance_deadline_iso": deadline_iso,
        "progress": {
            "submitted": submitted_total,
            "total": progress_denominator,
            "percent": progress_pct,
        },
        "your_status": your_status,
        "division_submissions": division_submissions,
        "featured_game": featured_game,
        "slate_games": slate_games,
        "standings_by_division": standings_by_division,
        "full_league_standings": full_league_standings,
        "activity": activity,
        "chat_enabled": True,
        "chat_messages": chat_messages,
        "is_commissioner": bool(is_commish),
        "is_read_only_admin": bool(is_owner and not is_commish),
        "can_run_league": bool(is_commish),
        "acting_team_name": acting,
        "state_version": int(league_row.get("state_version") or 0),
        "logos_download_url": str(league_row.get("logos_download_url") or "").strip() or None,
    }


    return owner_user_id


def _first_team_name_from_teams_data(teams_data: Optional[Dict[str, Any]]) -> Optional[str]:
    if not isinstance(teams_data, dict):
        return None
    rows = teams_data.get("teams")
    if not isinstance(rows, list):
        return None
    for row in rows:
        if not isinstance(row, dict):
            continue
        name = str(row.get("name") or row.get("school") or "").strip()
        if name:
            return name
    return None


def _resolve_bootstrap_team_name(
    teams_data: Optional[Dict[str, Any]],
    user_team: Optional[str] = None,
) -> str:
    clean = str(user_team or "").strip()
    if clean:
        return clean
    from_teams = _first_team_name_from_teams_data(teams_data)
    if from_teams:
        return from_teams
    from systems.teams_loader import load_league_config_from_json

    cfg = load_league_config_from_json()
    from_default = _first_team_name_from_teams_data(cfg if isinstance(cfg, dict) else None)
    if from_default:
        return from_default
    raise ValueError("Could not determine a team for league bootstrap")


def _minimal_bootstrap_coach_config() -> Dict[str, Any]:
    return {
        "name": "Staff",
        "age": 38,
        "playcalling": 5,
        "player_development": 5,
        "community_outreach": 5,
        "culture": 5,
        "recruiting": 5,
        "scheme_teach": 5,
        "offensive_style": "balanced",
        "defensive_style": "multiple_4_3",
        "winter_strength_pct": 50,
        "offensive_formation": "spread",
        "defensive_formation": "multiple_4_3",
    }


def _restore_cpu_coach_on_team(state: Dict[str, Any], team_name: str) -> None:
    from systems.coach_generator import generate_coach_for_team
    from systems.save_system import team_from_dict, team_to_dict

    teams_list = state.get("teams")
    if not isinstance(teams_list, list):
        return
    for idx, row in enumerate(teams_list):
        if not isinstance(row, dict):
            continue
        if str(row.get("name") or "") != team_name:
            continue
        team = team_from_dict(row)
        team.coach = generate_coach_for_team(team)
        teams_list[idx] = team_to_dict(team)
        break


def create_admin_league(
    owner_user_id: str,
    *,
    name: str,
    user_team: str,
    coach_config: Dict[str, Any],
    start_year: Optional[int] = None,
    teams_data: Optional[Dict[str, Any]] = None,
    allow_user_coach_firing: bool = False,
    transfers_disabled: bool = False,
    commissioner_user_id: Optional[str] = None,
    commissioner_email: Optional[str] = None,
    timezone: str = "America/New_York",
    defer_commish_setup: bool = False,
) -> Dict[str, Any]:
    """Platform owner creates a multiplayer league (same options as single-player new dynasty)."""
    from backend.services.league_service import create_save

    if not is_platform_owner_user(owner_user_id):
        raise PermissionError("only platform owner can create leagues")

    if teams_data is not None:
        team_rows = teams_data.get("teams") if isinstance(teams_data.get("teams"), list) else []
        if not team_rows:
            raise ValueError("teams_data must include a teams array")
        if len(team_rows) > 120:
            raise ValueError("multiplayer leagues support at most 120 teams")

    commish_id = resolve_commissioner_user_id(
        owner_user_id,
        commissioner_user_id=commissioner_user_id,
        commissioner_email=commissioner_email,
    )

    if defer_commish_setup:
        bootstrap_team = _resolve_bootstrap_team_name(teams_data, user_team or None)
        bootstrap_coach = _minimal_bootstrap_coach_config()
    else:
        bootstrap_team = str(user_team or "").strip()
        if not bootstrap_team:
            raise ValueError("user_team required")
        bootstrap_coach = coach_config or {}

    league_id = str(uuid.uuid4())
    save_dir = _league_dir(league_id)
    os.makedirs(save_dir, exist_ok=True)

    bootstrap_name = f"__mp_bootstrap_{league_id[:8]}"
    create_kwargs: Dict[str, Any] = {
        "start_year": start_year,
        "allow_user_coach_firing": allow_user_coach_firing,
        "transfers_disabled": transfers_disabled,
    }
    if teams_data is not None:
        create_kwargs["teams_data"] = teams_data
    bootstrap = create_save(
        owner_user_id,
        bootstrap_name,
        bootstrap_team,
        bootstrap_coach,
        **create_kwargs,
    )
    save_id = bootstrap.get("save_id")
    with db() as conn:
        row = conn.execute("SELECT save_dir FROM saves WHERE id=?", (save_id,)).fetchone()
    bootstrap_dir = str(row["save_dir"] or "") if row else ""
    if not bootstrap_dir or not os.path.isdir(bootstrap_dir):
        raise RuntimeError("failed to bootstrap league save")

    import shutil

    for entry in os.listdir(bootstrap_dir):
        shutil.move(os.path.join(bootstrap_dir, entry), os.path.join(save_dir, entry))
    shutil.rmtree(bootstrap_dir, ignore_errors=True)

    # Remove bootstrap index row
    with db() as conn:
        conn.execute("DELETE FROM saves WHERE id=?", (save_id,))

    # Multiplayer: no opening schedule picker — auto-build the shared calendar and start preseason.
    from backend.services.league_service import ensure_multiplayer_opening_schedule

    state = _load_state(save_dir)
    if defer_commish_setup:
        _restore_cpu_coach_on_team(state, bootstrap_team)
        state.pop("user_team", None)
        state.pop("user_coach_name", None)
        banks = state.get("offseason_coach_dev_banks")
        if isinstance(banks, dict):
            banks.pop(bootstrap_team, None)
        state.pop("offseason_coach_dev_bank", None)
    state["multiplayer_league"] = True
    state["multiplayer"] = {"league_id": league_id}
    if not defer_commish_setup:
        state["user_team"] = bootstrap_team
    ensure_multiplayer_opening_schedule(state)
    _save_state(save_dir, state)

    now = _now()
    commish_pin: Optional[str] = None
    commish_team: Optional[str] = None
    if not defer_commish_setup:
        commish_pin = generate_team_pin()
    commish_lookup = lookup_user_by_email(_user_email(commish_id)) or {}
    commish_display = str(
        commish_lookup.get("email") or commish_lookup.get("username") or commish_id
    ).strip()
    rules = {
        "transfers_enabled": not bool(transfers_disabled),
        "carousel_enabled": True,
        "allow_user_coach_firing": bool(allow_user_coach_firing),
    }
    with db() as conn:
        conn.execute(
            """
            INSERT INTO leagues (
              id, name, save_dir, status, created_by_user_id, commissioner_user_id,
              timezone, rules_json, created_at, updated_at
            ) VALUES (?,?,?,?,?,?,?,?,?,?)
            """,
            (
                league_id,
                name.strip(),
                save_dir,
                "active",
                owner_user_id,
                commish_id,
                timezone,
                json.dumps(rules),
                now,
                now,
            ),
        )
        conn.execute(
            """
            INSERT INTO league_members (
              id, league_id, user_id, team_name, role, status, control_mode,
              pin_hash, pin_updated_at, coach_setup_complete, joined_at
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                str(uuid.uuid4()),
                league_id,
                commish_id,
                None if defer_commish_setup else bootstrap_team,
                "commissioner",
                "unassigned" if defer_commish_setup else "active",
                "human",
                _hash_pin(commish_pin) if commish_pin else None,
                now if commish_pin else None,
                0 if defer_commish_setup else 1,
                now,
            ),
        )
        conn.execute(
            """
            INSERT INTO league_activity_log (id, league_id, actor_user_id, action, detail_json, created_at)
            VALUES (?,?,?,?,?,?)
            """,
            (
                str(uuid.uuid4()),
                league_id,
                owner_user_id,
                "league_created",
                json.dumps({"text": f"League «{name.strip()}» created", "icon": "🏟️"}),
                now,
            ),
        )

    from backend.services.league_notifications import ensure_notification_settings

    ensure_notification_settings(league_id)

    if not defer_commish_setup:
        commish_team = bootstrap_team

    return {
        "league_id": league_id,
        "name": name.strip(),
        "save_dir": save_dir,
        "commissioner_user_id": commish_id,
        "commissioner_email": commish_display,
        "commissioner_team": commish_team,
        "commissioner_pin": commish_pin,
        "defer_commish_setup": defer_commish_setup,
    }


def delete_admin_league(owner_user_id: str, league_id: str) -> Dict[str, Any]:
    """Platform owner soft-deletes a league (hidden from lists; recoverable)."""
    if not is_platform_owner_user(owner_user_id):
        raise PermissionError("only platform owner can delete leagues")
    league_row = _load_league_row(league_id)
    if not league_row:
        raise ValueError("league not found")
    if str(league_row.get("status") or "") == "deleted":
        raise ValueError("league already deleted")
    league_name = str(league_row.get("name") or league_id)
    now = _now()
    with db() as conn:
        conn.execute(
            "UPDATE leagues SET status='deleted', updated_at=? WHERE id=?",
            (now, league_id),
        )
        conn.execute(
            """
            INSERT INTO league_activity_log (id, league_id, actor_user_id, action, detail_json, created_at)
            VALUES (?,?,?,?,?,?)
            """,
            (
                str(uuid.uuid4()),
                league_id,
                owner_user_id,
                "league_deleted",
                json.dumps({"text": f"League «{league_name}» archived by admin", "icon": "🗑️"}),
                now,
            ),
        )
    return {"ok": True, "league_id": league_id, "name": league_name, "status": "deleted"}


def restore_admin_league(owner_user_id: str, league_id: str) -> Dict[str, Any]:
    """Platform owner restores a soft-deleted league."""
    if not is_platform_owner_user(owner_user_id):
        raise PermissionError("only platform owner can restore leagues")
    league_row = _load_league_row(league_id)
    if not league_row:
        raise ValueError("league not found")
    if str(league_row.get("status") or "") != "deleted":
        raise ValueError("league is not deleted")
    league_name = str(league_row.get("name") or league_id)
    now = _now()
    with db() as conn:
        conn.execute(
            "UPDATE leagues SET status='active', updated_at=? WHERE id=?",
            (now, league_id),
        )
        conn.execute(
            """
            INSERT INTO league_activity_log (id, league_id, actor_user_id, action, detail_json, created_at)
            VALUES (?,?,?,?,?,?)
            """,
            (
                str(uuid.uuid4()),
                league_id,
                owner_user_id,
                "league_restored",
                json.dumps({"text": f"League «{league_name}» restored by admin", "icon": "♻️"}),
                now,
            ),
        )
    return {"ok": True, "league_id": league_id, "name": league_name, "status": "active"}


def list_deleted_leagues_for_admin(owner_user_id: str) -> List[Dict[str, Any]]:
    if not is_platform_owner_user(owner_user_id):
        raise PermissionError("only platform owner can list deleted leagues")
    with db() as conn:
        rows = conn.execute(
            """
            SELECT id, name, status, updated_at, commissioner_user_id
            FROM leagues WHERE status='deleted'
            ORDER BY updated_at DESC
            """
        ).fetchall()
    return [
        {
            "league_id": str(r["id"]),
            "name": str(r["name"] or ""),
            "status": "deleted",
            "updated_at": int(r["updated_at"] or 0),
            "commissioner_user_id": str(r["commissioner_user_id"] or ""),
        }
        for r in rows
    ]


def permanently_delete_admin_league(owner_user_id: str, league_id: str) -> Dict[str, Any]:
    """Platform owner permanently removes an archived league and its save files."""
    if not is_platform_owner_user(owner_user_id):
        raise PermissionError("only platform owner can permanently delete leagues")
    league_row = _load_league_row(league_id)
    if not league_row:
        raise ValueError("league not found")
    if str(league_row.get("status") or "") != "deleted":
        raise ValueError("only archived leagues can be permanently deleted — archive it first")
    league_name = str(league_row.get("name") or league_id)
    save_dir = str(league_row.get("save_dir") or "").strip()
    with db() as conn:
        conn.execute("DELETE FROM league_submit_status WHERE league_id=?", (league_id,))
        conn.execute("DELETE FROM league_activity_log WHERE league_id=?", (league_id,))
        conn.execute("DELETE FROM league_chat_messages WHERE league_id=?", (league_id,))
        conn.execute("DELETE FROM league_invites WHERE league_id=?", (league_id,))
        conn.execute("DELETE FROM league_join_requests WHERE league_id=?", (league_id,))
        conn.execute("DELETE FROM league_email_log WHERE league_id=?", (league_id,))
        conn.execute("DELETE FROM league_notification_settings WHERE league_id=?", (league_id,))
        conn.execute("DELETE FROM league_members WHERE league_id=?", (league_id,))
        conn.execute("DELETE FROM leagues WHERE id=?", (league_id,))
    if save_dir and os.path.isdir(save_dir):
        shutil.rmtree(save_dir, ignore_errors=False)
    return {"ok": True, "league_id": league_id, "name": league_name, "permanently_deleted": True}


def assign_team_to_member(
    league_id: str,
    actor_user_id: str,
    target_user_id: str,
    team_name: str,
    *,
    pin: Optional[str] = None,
) -> Dict[str, Any]:
    league_row = _require_commish_write(league_id, actor_user_id)
    team_name = str(team_name or "").strip()
    if not team_name:
        raise ValueError("team_name required")
    pin_value = (pin or generate_team_pin()).strip()
    if not re.fullmatch(r"\d{6}", pin_value):
        raise ValueError("PIN must be 6 digits")

    save_dir = str(league_row.get("save_dir") or "")
    state = _load_state(save_dir)
    team_names = {
        str(r.get("name") or "")
        for r in (state.get("teams") or [])
        if isinstance(r, dict) and r.get("name")
    }
    if team_name not in team_names:
        raise ValueError(f"{team_name} is not a team in this league")
    if len(team_names) > 120:
        raise ValueError("league exceeds the 120-team maximum")

    now = _now()
    with db() as conn:
        taken = conn.execute(
            """
            SELECT user_id FROM league_members
            WHERE league_id=? AND team_name=? AND status='active' AND user_id != ?
            """,
            (league_id, team_name, target_user_id),
        ).fetchone()
        if taken:
            raise ValueError(f"{team_name} is already assigned to another coach")
        existing = conn.execute(
            """
            SELECT id, team_name FROM league_members
            WHERE league_id=? AND user_id=? AND status != 'removed'
            """,
            (league_id, target_user_id),
        ).fetchone()
        if existing:
            prev_team = str(existing["team_name"] or "").strip()
            reset_setup = prev_team != team_name
            if reset_setup:
                conn.execute(
                    """
                    UPDATE league_members
                    SET team_name=?, status='active', pin_hash=?, pin_updated_at=?,
                        control_mode='human', coach_setup_complete=0
                    WHERE league_id=? AND user_id=? AND status != 'removed'
                    """,
                    (team_name, _hash_pin(pin_value), now, league_id, target_user_id),
                )
            else:
                conn.execute(
                    """
                    UPDATE league_members
                    SET team_name=?, status='active', pin_hash=?, pin_updated_at=?,
                        control_mode='human'
                    WHERE league_id=? AND user_id=? AND status != 'removed'
                    """,
                    (team_name, _hash_pin(pin_value), now, league_id, target_user_id),
                )
        else:
            conn.execute(
                """
                INSERT INTO league_members (
                  id, league_id, user_id, team_name, role, status, control_mode,
                  pin_hash, pin_updated_at, coach_setup_complete, joined_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    str(uuid.uuid4()),
                    league_id,
                    target_user_id,
                    team_name,
                    "coach",
                    "active",
                    "human",
                    _hash_pin(pin_value),
                    now,
                    0,
                    now,
                ),
            )
    return {"team_name": team_name, "pin": pin_value, "user_id": target_user_id}


def assign_team_by_email(
    league_id: str,
    actor_user_id: str,
    email: str,
    team_name: str,
    *,
    pin: Optional[str] = None,
) -> Dict[str, Any]:
    found = lookup_user_by_email(email)
    if not found:
        raise ValueError(
            f"No account found for {email.strip()}. They must sign in to FND once before you can assign a team."
        )
    return assign_team_to_member(
        league_id,
        actor_user_id,
        str(found["user_id"]),
        team_name,
        pin=pin,
    )


def reset_member_pin(
    league_id: str,
    actor_user_id: str,
    target_user_id: str,
    *,
    pin: Optional[str] = None,
) -> Dict[str, Any]:
    _require_commish_write(league_id, actor_user_id)
    pin_value = (pin or generate_team_pin()).strip()
    if not re.fullmatch(r"\d{6}", pin_value):
        raise ValueError("PIN must be 6 digits")
    with db() as conn:
        row = conn.execute(
            """
            SELECT team_name FROM league_members
            WHERE league_id=? AND user_id=? AND status='active' AND team_name IS NOT NULL
            """,
            (league_id, target_user_id),
        ).fetchone()
        if not row or not row["team_name"]:
            raise ValueError("member has no assigned team")
        team_name = str(row["team_name"])
        now = _now()
        conn.execute(
            """
            UPDATE league_members
            SET pin_hash=?, pin_updated_at=?
            WHERE league_id=? AND user_id=? AND status='active'
            """,
            (_hash_pin(pin_value), now, league_id, target_user_id),
        )
    return {"team_name": team_name, "pin": pin_value, "user_id": target_user_id}


def _normalize_logos_download_url(raw: Optional[str]) -> Optional[str]:
    """Allow clearing with blank; otherwise require http(s) URL."""
    url = str(raw or "").strip()
    if not url:
        return None
    if len(url) > 2000:
        raise ValueError("logos download link is too long")
    lower = url.lower()
    if not (lower.startswith("http://") or lower.startswith("https://")):
        raise ValueError("logos download link must start with http:// or https://")
    return url


def update_league_settings(
    league_id: str,
    actor_user_id: str,
    *,
    advance_mode: Optional[str] = None,
    advance_deadline_dow: Optional[int] = None,
    advance_deadline_time_local: Optional[str] = None,
    advance_interval_hours: Any = ...,
    submit_lockout_minutes: Optional[int] = None,
    timezone: Optional[str] = None,
    email_week_advanced: Optional[bool] = None,
    email_advance_reminder_24h: Optional[bool] = None,
    email_advance_lockout: Optional[bool] = None,
    logos_download_url: Optional[str] = None,
) -> Dict[str, Any]:
    league_row = _load_league_row(league_id)
    if not league_row:
        raise ValueError("league not found")
    if str(league_row.get("commissioner_user_id") or "") != actor_user_id:
        raise PermissionError("commissioner only")

    mode = str(advance_mode or league_row.get("advance_mode") or "manual").strip().lower()
    if mode not in ("manual", "auto"):
        raise ValueError("advance_mode must be manual or auto")
    dow = advance_deadline_dow if advance_deadline_dow is not None else league_row.get("advance_deadline_dow")
    time_local = (
        advance_deadline_time_local
        if advance_deadline_time_local is not None
        else league_row.get("advance_deadline_time_local")
    )
    if advance_interval_hours is ...:
        interval_hours = _advance_interval_hours(league_row)
    else:
        interval_hours = _normalize_advance_interval_hours(advance_interval_hours)
    if mode == "auto" and interval_hours is None and dow is None:
        raise ValueError("Choose a weekly deadline day, or every 12/24 hours")
    lockout = (
        int(submit_lockout_minutes)
        if submit_lockout_minutes is not None
        else int(league_row.get("submit_lockout_minutes") or 5)
    )
    tz = str(timezone or league_row.get("timezone") or "America/New_York").strip()
    if logos_download_url is not None:
        logos_url = _normalize_logos_download_url(logos_download_url)
    else:
        logos_url = str(league_row.get("logos_download_url") or "").strip() or None
    now = _now()
    prev_interval = _advance_interval_hours(league_row)
    cycle_anchor = league_row.get("advance_cycle_anchor_at")
    # Starting or changing interval schedule: reset the cycle clock so the next
    # advance is interval_hours from now (not an old weekly last_auto_advance_at).
    if mode == "auto" and interval_hours is not None and interval_hours != prev_interval:
        cycle_anchor = now
        with db() as conn:
            conn.execute(
                """
                UPDATE leagues
                SET advance_mode=?, advance_deadline_dow=?, advance_deadline_time_local=?,
                    advance_interval_hours=?, advance_cycle_anchor_at=?, last_auto_advance_at=?,
                    submit_lockout_minutes=?, timezone=?, logos_download_url=?, updated_at=?
                WHERE id=?
                """,
                (
                    mode,
                    None if interval_hours else dow,
                    str(time_local or "23:59"),
                    interval_hours,
                    cycle_anchor,
                    now,
                    lockout,
                    tz,
                    logos_url,
                    now,
                    league_id,
                ),
            )
    else:
        with db() as conn:
            conn.execute(
                """
                UPDATE leagues
                SET advance_mode=?, advance_deadline_dow=?, advance_deadline_time_local=?,
                    advance_interval_hours=?, advance_cycle_anchor_at=?,
                    submit_lockout_minutes=?, timezone=?, logos_download_url=?, updated_at=?
                WHERE id=?
                """,
                (
                    mode,
                    None if interval_hours else dow,
                    str(time_local or "23:59"),
                    interval_hours,
                    None if interval_hours is None else cycle_anchor,
                    lockout,
                    tz,
                    logos_url,
                    now,
                    league_id,
                ),
            )
    from backend.services.league_notifications import get_notification_settings, update_notification_settings

    notifications = get_notification_settings(league_id)
    if any(
        v is not None
        for v in (email_week_advanced, email_advance_reminder_24h, email_advance_lockout)
    ):
        notifications = update_notification_settings(
            league_id,
            email_week_advanced=email_week_advanced,
            email_advance_reminder_24h=email_advance_reminder_24h,
            email_advance_lockout=email_advance_lockout,
        )
    return {
        "advance_mode": mode,
        "advance_deadline_dow": None if interval_hours else dow,
        "advance_deadline_time_local": str(time_local or "23:59"),
        "advance_interval_hours": interval_hours,
        "submit_lockout_minutes": lockout,
        "timezone": tz,
        "logos_download_url": logos_url,
        "notifications": notifications,
    }


def _mp_week_sim_context(league_id: str, state: Dict[str, Any]) -> Tuple[set[str], set[str]]:
    stage_key = _stage_key_from_state(state)
    submitted = _submitted_teams(league_id, stage_key)
    human = {str(m["team_name"]) for m in _human_teams(league_id) if m.get("team_name")}
    return human, submitted


def apply_league_coach_prep(
    league_id: str,
    user_id: str,
    team_name: str,
    prep: Dict[str, Any],
) -> Dict[str, Any]:
    """Save coach prep for the current stage without advancing the shared league."""
    import copy

    from backend.services.league_service import apply_coach_prep_state

    league_row = _verify_team_game_access(league_id, user_id, team_name)
    save_dir = str(league_row.get("save_dir") or "")
    canonical = _load_state(save_dir)
    working = copy.deepcopy(canonical)
    working["user_team"] = team_name
    from backend.services.league_service import (
        hydrate_mp_team_coach_dev_view,
        hydrate_mp_team_improvements_bank_view,
        is_multiplayer_league_state,
        persist_mp_team_coach_dev_slice,
        persist_mp_team_improvements_bank_slice,
    )

    if is_multiplayer_league_state(working):
        hydrate_mp_team_improvements_bank_view(working, team_name)
        hydrate_mp_team_coach_dev_view(working, team_name)
    working = apply_coach_prep_state(working, prep if isinstance(prep, dict) else {})
    persist_mp_team_improvements_bank_slice(working, team_name)
    persist_mp_team_coach_dev_slice(working, team_name)
    merged = _merge_coach_state_into_canonical(canonical, working, team_name)
    merged["user_team"] = team_name
    mp = merged.get("multiplayer")
    if not isinstance(mp, dict):
        mp = {}
    mp["league_id"] = league_id
    mp["team_name"] = team_name
    merged["multiplayer"] = mp
    _save_state(save_dir, merged)
    now = _now()
    with db() as conn:
        conn.execute(
            "UPDATE leagues SET state_version=state_version+1, updated_at=? WHERE id=?",
            (now, league_id),
        )
    return get_league_game_bundle(league_id, user_id, team_name)


def commish_advance_league(
    league_id: str,
    user_id: str,
    *,
    cross_region_picks: Optional[List[Dict[str, Any]]] = None,
    advance_source: str = "manual",
) -> Dict[str, Any]:
    """Sim/advance one league step (commissioner)."""
    from backend.services.league_service import (
        _advance_playoff_one_round_state,
        _playoffs_global_completed,
        advance_offseason_state,
        advance_preseason_state,
        finalize_season_to_summary_for_save_dir,
        finish_season_state,
        sim_week_state,
    )
    from systems.league_history import load_league_history, save_league_history
    from systems.records_system import load_records, save_records
    from systems.save_system import league_history_path, records_path

    league_row = _verify_commish_game_access(league_id, user_id)
    save_dir = str(league_row.get("save_dir") or "")
    state = _load_state(save_dir)
    completed_stage_key = _stage_key_from_state(state)
    league_name = str(league_row.get("name") or "League")
    phase = str(state.get("season_phase") or "regular").strip().lower()

    league_history: Dict[str, Any] = {"seasons": []}
    try:
        league_history = load_league_history(league_history_path(save_dir))
    except Exception:
        pass

    mp_human, mp_submitted = _mp_week_sim_context(league_id, state)
    state.pop("user_team", None)

    if phase == "preseason":
        from backend.services.league_service import (
            PRESEASON_STAGES,
            is_multiplayer_league_state,
            simulate_multiplayer_preseason_scrimmage_stage,
        )

        stages = state.get("preseason_stages") or list(PRESEASON_STAGES)
        idx = int(state.get("preseason_stage_index", 0))
        if (
            is_multiplayer_league_state(state)
            and idx < len(stages)
            and stages[idx] in ("Scrimmage 1", "Scrimmage 2")
        ):
            human_teams = [
                str(m["team_name"])
                for m in _human_teams(league_id)
                if m.get("team_name")
            ]
            simulate_multiplayer_preseason_scrimmage_stage(state, human_teams, stages[idx])
        out = advance_preseason_state(state, {})
        state = out.get("state") if isinstance(out, dict) and isinstance(out.get("state"), dict) else state
        action_label = "Preseason advanced"
    elif phase == "regular":
        completed_week = int(state.get("current_week", 1))
        state = sim_week_state(state, mp_human_teams=mp_human, mp_submitted_teams=mp_submitted)
        _sync_mp_inbox_emails_for_human_teams(
            state,
            league_id,
            completed_week=completed_week,
            checklist_week=int(state.get("current_week", 1)),
        )
        action_label = f"Week {int(state.get('current_week', 1))} simulated"
    elif phase == "playoffs":
        playoffs_now = state.get("playoffs") if isinstance(state.get("playoffs"), dict) else {}
        if _playoffs_global_completed(playoffs_now):
            state = finalize_season_to_summary_for_save_dir(state, save_dir)
            action_label = "Season archived — season summary"
        else:
            state = _advance_playoff_one_round_state(state)
            _sync_mp_inbox_emails_for_human_teams(state, league_id, playoff_round=True)
            playoffs_after = state.get("playoffs") if isinstance(state.get("playoffs"), dict) else {}
            if _playoffs_global_completed(playoffs_after):
                state = finalize_season_to_summary_for_save_dir(state, save_dir)
                action_label = "Championship complete — season summary"
            else:
                action_label = "Playoff round advanced"
    elif phase == "season_summary":
        from backend.services.league_service import advance_mp_season_summary_or_planning_state

        human = {str(m["team_name"]) for m in _human_teams(league_id) if m.get("team_name")}
        action_label = advance_mp_season_summary_or_planning_state(
            state,
            league_history,
            human_teams=human,
        )
        save_league_history(league_history, league_history_path(save_dir))
    elif phase == "offseason":
        from backend.services.league_service import _bulk_cpu_offseason_advance_body, advance_offseason_state

        idx_before = int(state.get("offseason_stage_index", 0) or 0)
        # Commissioner sim uses bulk CPU bodies and may need two passes for
        # simulate-then-review stages (winter, spring, transfers, 7-on-7).
        for _ in range(5):
            body = _bulk_cpu_offseason_advance_body(state)
            state = advance_offseason_state(
                state,
                body,
                league_history=league_history,
                user_id=user_id,
                mp_human_teams=mp_human,
                mp_submitted_teams=mp_submitted,
            )
            idx_after = int(state.get("offseason_stage_index", 0) or 0)
            phase_after = str(state.get("season_phase") or "").strip().lower()
            if idx_after != idx_before or phase_after != "offseason":
                break
        action_label = "Offseason advanced"
    elif phase == "schedule_planning":
        from backend.services.league_service import advance_schedule_planning_league_state

        state = advance_schedule_planning_league_state(state, league_history=league_history)
        save_league_history(league_history, league_history_path(save_dir))
        action_label = "Schedule planning completed"
    else:
        raise ValueError(f"Cannot advance league from season_phase={phase!r}")

    from backend.services.league_service import (
        repair_multiplayer_7on7_storage,
        repair_multiplayer_coach_inbox_storage,
        repair_multiplayer_offseason_training_storage,
        repair_multiplayer_offseason_improvements_storage,
        repair_multiplayer_coach_dev_storage,
        repair_multiplayer_scrimmage_storage,
    )

    repair_multiplayer_scrimmage_storage(state)
    repair_multiplayer_7on7_storage(state)
    repair_multiplayer_coach_inbox_storage(state)
    repair_multiplayer_offseason_training_storage(state)
    repair_multiplayer_offseason_improvements_storage(state)
    repair_multiplayer_coach_dev_storage(state)
    _materialize_mp_carried_gameplans_for_league(state, league_id)
    _save_state(save_dir, state)
    now = _now()
    with db() as conn:
        conn.execute(
            "UPDATE leagues SET state_version=state_version+1, updated_at=? WHERE id=?",
            (now, league_id),
        )
        conn.execute(
            """
            INSERT INTO league_activity_log (id, league_id, actor_user_id, action, detail_json, created_at)
            VALUES (?,?,?,?,?,?)
            """,
            (
                str(uuid.uuid4()),
                league_id,
                user_id,
                "commish_advance",
                json.dumps({"text": action_label, "icon": "⏩"}),
                now,
            ),
        )
        if phase == "regular":
            unsubmitted = sorted(mp_human - mp_submitted)
            if unsubmitted:
                conn.execute(
                    """
                    INSERT INTO league_activity_log (id, league_id, actor_user_id, action, detail_json, created_at)
                    VALUES (?,?,?,?,?,?)
                    """,
                    (
                        str(uuid.uuid4()),
                        league_id,
                        user_id,
                        "cpu_week",
                        json.dumps(
                            {
                                "text": f"CPU week for: {', '.join(unsubmitted)}",
                                "icon": "🤖",
                            }
                        ),
                        now,
                    ),
                )

    try:
        from backend.services.league_notifications import notify_week_advanced

        notify_week_advanced(
            league_id,
            advance_source=advance_source,
            action_label=action_label,
            completed_stage_key=completed_stage_key,
            league_name=league_name,
        )
    except Exception:
        logger.exception("Failed to send week-advanced notifications for league %s", league_id)

    return {
        "ok": True,
        "season_phase": str(state.get("season_phase") or ""),
        "current_week": int(state.get("current_week", 1) or 1),
        "message": action_label,
    }


def _human_team_names_for_league(league_id: str) -> set[str]:
    with db() as conn:
        rows = conn.execute(
            """
            SELECT team_name FROM league_members
            WHERE league_id=? AND status='active' AND team_name IS NOT NULL AND team_name != ''
            """,
            (league_id,),
        ).fetchall()
    return {str(r["team_name"]) for r in rows if r["team_name"]}


def build_commish_cross_region_planning(
    league_id: str,
    user_id: str,
) -> Dict[str, Any]:
    """Out-of-region schedule picker data for human schools (commissioner only)."""
    from backend.services.league_service import (
        _any_team_needs_cross_region_planning,
        _human_teams_missing_cross_region_picks,
        _schedule_planning_info_for_user,
        _user_cross_region_picks_complete,
    )
    from systems.save_system import team_from_dict
    from systems.schedule_planning import parse_stored_pick

    _verify_commish_view_access(league_id, user_id)
    league_row = _load_league_row(league_id)
    if not league_row:
        raise ValueError("league not found")
    save_dir = str(league_row.get("save_dir") or "")
    state = _load_state(save_dir)
    phase = str(state.get("season_phase") or "").strip().lower()
    season_year = int(state.get("current_year", 1) or 1)
    human = _human_team_names_for_league(league_id)
    teams = {
        t["name"]: team_from_dict(t)
        for t in (state.get("teams") or [])
        if isinstance(t, dict) and t.get("name")
    }

    inactive = phase != "season_summary"
    if inactive or not _any_team_needs_cross_region_planning(teams):
        return {
            "active": False,
            "season_year": season_year,
            "teams": [],
            "all_complete": True,
            "missing_teams": [],
        }

    human_with_slots = sorted(
        t for t in human if _schedule_planning_info_for_user(teams, t)
    )
    if not human_with_slots:
        return {
            "active": False,
            "season_year": season_year,
            "teams": [],
            "all_complete": True,
            "missing_teams": [],
        }

    picks_raw = state.get("cross_region_picks") if isinstance(state.get("cross_region_picks"), dict) else {}
    team_rows: List[Dict[str, Any]] = []
    for team_name in human_with_slots:
        info = _schedule_planning_info_for_user(teams, team_name)
        if not info:
            continue
        user_picks = picks_raw.get(team_name) if isinstance(picks_raw, dict) else {}
        selections: List[Dict[str, Any]] = []
        for slot in info.get("slots") or []:
            if not isinstance(slot, dict):
                continue
            si = int(slot.get("slot_index", 0))
            raw = None
            if isinstance(user_picks, dict):
                raw = user_picks.get(si)
                if raw is None:
                    raw = user_picks.get(str(si))
            pick = parse_stored_pick(raw)
            selections.append(
                {
                    "slot_index": si,
                    "opponent": pick.opponent or "",
                    "user_home": pick.user_home,
                }
            )
        team_rows.append(
            {
                "team_name": team_name,
                "picks_complete": _user_cross_region_picks_complete(state, teams, team_name),
                "schedule_planning_info": info,
                "selections": selections,
            }
        )

    missing = _human_teams_missing_cross_region_picks(state, teams, human)
    return {
        "active": True,
        "season_year": season_year,
        "teams": team_rows,
        "all_complete": len(missing) == 0,
        "missing_teams": missing,
    }


def save_commish_cross_region_picks(
    league_id: str,
    user_id: str,
    team_name: str,
    cross_region_picks: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """Commissioner sets one human school's out-of-region schedule during season summary."""
    from backend.services.league_service import (
        _merge_cross_region_picks_for_team,
        _schedule_planning_info_for_user,
    )
    from systems.save_system import team_from_dict

    _verify_commish_game_access(league_id, user_id)
    team_name = str(team_name or "").strip()
    if not team_name:
        raise ValueError("team_name required")
    human = _human_team_names_for_league(league_id)
    if team_name not in human:
        raise ValueError(f"{team_name} is not a human-controlled team in this league.")

    league_row = _load_league_row(league_id) or {}
    save_dir = str(league_row.get("save_dir") or "")
    state = _load_state(save_dir)
    phase = str(state.get("season_phase") or "").strip().lower()
    if phase != "season_summary":
        raise ValueError("Out-of-region schedules can only be set during season summary.")

    teams = {
        t["name"]: team_from_dict(t)
        for t in (state.get("teams") or [])
        if isinstance(t, dict) and t.get("name")
    }
    if not _schedule_planning_info_for_user(teams, team_name):
        raise ValueError(f"{team_name} does not require out-of-region schedule picks.")

    _merge_cross_region_picks_for_team(state, teams, team_name, cross_region_picks)
    state.pop("user_team", None)
    _save_state(save_dir, state)
    now = _now()
    with db() as conn:
        conn.execute(
            "UPDATE leagues SET state_version=state_version+1, updated_at=? WHERE id=?",
            (now, league_id),
        )
    planning = build_commish_cross_region_planning(league_id, user_id)
    return {"ok": True, "team_name": team_name, "cross_region_planning": planning}


def build_commish_dashboard(league_id: str, user_id: str) -> Dict[str, Any]:
    league_row, read_only = _verify_commish_view_access(league_id, user_id)
    if not read_only:
        try_auto_advance_league(league_id)
        league_row = _load_league_row(league_id) or league_row
    save_dir = str(league_row.get("save_dir") or "")
    state = _load_state(save_dir)
    teams_meta = _teams_meta_from_state(state)
    all_teams = sorted(teams_meta.keys(), key=lambda n: n.lower())
    stage_key = _stage_key_from_state(state)
    submitted = _submitted_teams(league_id, stage_key)

    phase = str(state.get("season_phase") or "regular").strip().lower()
    current_week = int(state.get("current_week", 1) or 1)
    weeks = state.get("weeks") or []
    total_weeks = len(weeks) if isinstance(weeks, list) and weeks else 12
    week_label = f"Week {current_week} of {total_weeks}"
    if phase == "preseason":
        stages = state.get("preseason_stages") or []
        idx = int(state.get("preseason_stage_index", 0) or 0)
        week_label = f"Preseason — {stages[idx] if idx < len(stages) else 'Complete'}"
    elif phase == "offseason":
        stages = state.get("offseason_stages") or []
        idx = int(state.get("offseason_stage_index", 0) or 0)
        week_label = f"Offseason — {stages[idx] if idx < len(stages) else 'Complete'}"
    elif phase == "playoffs":
        week_label = "Playoffs"
    elif phase == "season_summary":
        week_label = "Season summary — set out-of-region schedules"

    with db() as conn:
        member_rows = conn.execute(
            """
            SELECT m.user_id, m.team_name, m.role, m.status, m.control_mode, m.coach_setup_complete,
                   u.email, u.username
            FROM league_members m
            LEFT JOIN users u ON u.id = m.user_id
            WHERE m.league_id=? AND m.status != 'removed'
            ORDER BY m.joined_at ASC
            """,
            (league_id,),
        ).fetchall()
        invite_rows = conn.execute(
            """
            SELECT id, email, status, created_at FROM league_invites
            WHERE league_id=? AND status='pending'
            ORDER BY created_at DESC
            """,
            (league_id,),
        ).fetchall()
        join_request_rows = conn.execute(
            """
            SELECT r.id, r.user_id, r.message, r.created_at, u.email, u.username
            FROM league_join_requests r
            LEFT JOIN users u ON u.id = r.user_id
            WHERE r.league_id=? AND r.status='pending'
            ORDER BY r.created_at DESC
            """,
            (league_id,),
        ).fetchall()

    assigned_teams = {
        str(r["team_name"])
        for r in member_rows
        if r["team_name"] and str(r["status"]) == "active"
    }
    vacant_teams = [t for t in all_teams if t not in assigned_teams]

    members: List[Dict[str, Any]] = []
    for r in member_rows:
        team = str(r["team_name"] or "")
        email = str(r["email"] or r["username"] or "").strip()
        members.append(
            {
                "user_id": str(r["user_id"]),
                "email": email,
                "team_name": team or None,
                "role": str(r["role"] or "coach"),
                "status": str(r["status"] or ""),
                "control_mode": str(r["control_mode"] or "human"),
                "coach_setup_complete": bool(r["coach_setup_complete"]),
                "submitted": bool(team and team in submitted),
            }
        )

    pending_invites = [
        {
            "invite_id": str(inv["id"]),
            "email": str(inv["email"]),
            "status": str(inv["status"]),
            "created_at": int(inv["created_at"]),
        }
        for inv in invite_rows
    ]

    pending_join_requests = [
        {
            "request_id": str(req["id"]),
            "user_id": str(req["user_id"]),
            "email": str(req["email"] or req["username"] or "").strip(),
            "message": str(req["message"] or "").strip() or None,
            "created_at": int(req["created_at"]),
        }
        for req in join_request_rows
    ]

    human_team_names = {
        str(r["team_name"]) for r in member_rows if r["team_name"] and str(r["status"]) == "active"
    }
    submitted_humans = len([t for t in human_team_names if t in submitted])
    progress_denominator = max(len(human_team_names), 1)
    progress_pct = int(round(100 * submitted_humans / progress_denominator))

    league_name = str(league_row.get("name") or "League")
    deadline_iso = _advance_countdown_iso(league_row)

    from backend.services.league_notifications import get_notification_settings

    notification_settings = get_notification_settings(league_id)

    acting_team: Optional[str] = None
    coach_setup_complete = False
    for r in member_rows:
        if str(r["user_id"]) == user_id and r["team_name"] and str(r["status"]) == "active":
            acting_team = str(r["team_name"])
            coach_setup_complete = bool(r["coach_setup_complete"])
            break
    your_submitted = bool(acting_team and acting_team in submitted)
    unsubmit_locked = _is_unsubmit_locked(league_row)
    your_status = {
        "submitted": your_submitted,
        "can_unsubmit": your_submitted and not unsubmit_locked,
        "label": "You're submitted" if your_submitted else "Not submitted yet",
        "sub_label": (
            f"Locked for {week_label}"
            if your_submitted and unsubmit_locked
            else (f"Locked for {week_label}" if your_submitted else f"Complete prep for {week_label}")
        ),
    }

    return {
        "league_id": league_id,
        "league_name": league_name,
        "week_label": week_label,
        "season_phase": phase,
        "stage_key": stage_key,
        "progress": {
            "submitted": submitted_humans,
            "total": len(human_team_names),
            "percent": progress_pct,
        },
        "settings": {
            "advance_mode": str(league_row.get("advance_mode") or "manual"),
            "advance_deadline_dow": league_row.get("advance_deadline_dow"),
            "advance_deadline_time_local": str(league_row.get("advance_deadline_time_local") or "23:59"),
            "advance_interval_hours": _advance_interval_hours(league_row),
            "submit_lockout_minutes": int(league_row.get("submit_lockout_minutes") or 5),
            "timezone": str(league_row.get("timezone") or "America/New_York"),
            "advance_deadline_iso": deadline_iso,
            "countdown_value": _format_countdown(deadline_iso),
            "notifications": notification_settings,
            "logos_download_url": str(league_row.get("logos_download_url") or "").strip() or None,
        },
        "members": members,
        "pending_invites": pending_invites,
        "pending_join_requests": pending_join_requests,
        "vacant_teams": vacant_teams,
        "all_teams": all_teams,
        "state_version": int(league_row.get("state_version") or 0),
        "is_read_only_admin": read_only,
        "can_manage": not read_only,
        "acting_team_name": acting_team,
        "coach_setup_complete": coach_setup_complete,
        "your_status": your_status,
        "cross_region_planning": build_commish_cross_region_planning(league_id, user_id),
    }


def _is_unsubmit_locked(league_row: Dict[str, Any]) -> bool:
    """True when coaches can no longer unsubmit (lockout window before auto-advance)."""
    if str(league_row.get("advance_mode") or "manual").lower() != "auto":
        return False
    deadline_iso = _advance_countdown_iso(league_row)
    if not deadline_iso:
        return False
    lockout_minutes = int(league_row.get("submit_lockout_minutes") or 5)
    try:
        deadline = datetime.fromisoformat(deadline_iso)
        if deadline.tzinfo is None:
            deadline = deadline.replace(tzinfo=ZoneInfo("UTC"))
        now = datetime.now(deadline.tzinfo)
        lockout_start = deadline - timedelta(minutes=lockout_minutes)
        return now >= lockout_start
    except Exception:
        return False


def _verify_active_team_member(league_id: str, user_id: str, team_name: str) -> None:
    with db() as conn:
        row = conn.execute(
            """
            SELECT 1 FROM league_members
            WHERE league_id=? AND user_id=? AND team_name=? AND status='active'
            LIMIT 1
            """,
            (league_id, user_id, team_name),
        ).fetchone()
    if not row:
        raise PermissionError("not assigned to this team")


def submit_league_week(league_id: str, user_id: str, team_name: str) -> Dict[str, Any]:
    league_row = _load_league_row(league_id)
    if not league_row:
        raise ValueError("league not found")
    _verify_active_team_member(league_id, user_id, team_name)
    save_dir = str(league_row.get("save_dir") or "")
    state = _load_state(save_dir)
    stage_key = _stage_key_from_state(state)
    now = _now()
    with db() as conn:
        conn.execute(
            """
            INSERT INTO league_submit_status (league_id, user_id, team_name, stage_key, submitted_at)
            VALUES (?,?,?,?,?)
            ON CONFLICT(league_id, user_id, team_name, stage_key)
            DO UPDATE SET submitted_at=excluded.submitted_at
            """,
            (league_id, user_id, team_name, stage_key, now),
        )
        conn.execute(
            """
            INSERT INTO league_activity_log (id, league_id, actor_user_id, action, detail_json, created_at)
            VALUES (?,?,?,?,?,?)
            """,
            (
                str(uuid.uuid4()),
                league_id,
                user_id,
                "submit_week",
                json.dumps({"text": f"{team_name} submitted for {stage_key}", "icon": "✅"}),
                now,
            ),
        )
    return {"ok": True, "team_name": team_name, "stage_key": stage_key, "submitted_at": now}


def unsubmit_league_week(league_id: str, user_id: str, team_name: str) -> Dict[str, Any]:
    league_row = _load_league_row(league_id)
    if not league_row:
        raise ValueError("league not found")
    _verify_active_team_member(league_id, user_id, team_name)
    if _is_unsubmit_locked(league_row):
        lockout = int(league_row.get("submit_lockout_minutes") or 5)
        raise ValueError(
            f"Cannot unsubmit within {lockout} minutes of the advance deadline."
        )
    save_dir = str(league_row.get("save_dir") or "")
    state = _load_state(save_dir)
    stage_key = _stage_key_from_state(state)
    with db() as conn:
        conn.execute(
            """
            DELETE FROM league_submit_status
            WHERE league_id=? AND user_id=? AND team_name=? AND stage_key=?
            """,
            (league_id, user_id, team_name, stage_key),
        )
        now = _now()
        conn.execute(
            """
            INSERT INTO league_activity_log (id, league_id, actor_user_id, action, detail_json, created_at)
            VALUES (?,?,?,?,?,?)
            """,
            (
                str(uuid.uuid4()),
                league_id,
                user_id,
                "unsubmit_week",
                json.dumps({"text": f"{team_name} unsubmitted for {stage_key}", "icon": "↩"}),
                now,
            ),
        )
    return {"ok": True, "team_name": team_name, "stage_key": stage_key}


def _activity_time_label(ts: int) -> str:
    if not ts:
        return ""
    try:
        now = _now()
        delta = max(0, now - int(ts))
        if delta < 60:
            return "Just now"
        if delta < 3600:
            mins = delta // 60
            return f"{mins}m ago"
        if delta < 86400:
            hours = delta // 3600
            return f"{hours}h ago"
        if delta < 86400 * 7:
            days = delta // 86400
            return f"{days}d ago"
        return datetime.fromtimestamp(int(ts)).strftime("%b %d")
    except Exception:
        return ""


def _verify_league_member_or_owner(league_id: str, user_id: str) -> Dict[str, Any]:
    league_row = _load_league_row(league_id)
    if not league_row:
        raise ValueError("league not found")
    if is_platform_owner_user(user_id):
        return league_row
    if str(league_row.get("commissioner_user_id") or "") == user_id:
        return league_row
    with db() as conn:
        row = conn.execute(
            """
            SELECT team_name, status FROM league_members
            WHERE league_id=? AND user_id=? AND status != 'removed'
            LIMIT 1
            """,
            (league_id, user_id),
        ).fetchone()
    if not row:
        raise PermissionError("not a league member")
    return league_row


def list_league_chat_messages(
    league_id: str,
    user_id: str,
    *,
    limit: int = 40,
) -> List[Dict[str, Any]]:
    _verify_league_member_or_owner(league_id, user_id)
    limit = max(1, min(100, int(limit or 40)))
    with db() as conn:
        rows = conn.execute(
            """
            SELECT id, user_id, team_name, display_name, body, created_at
            FROM league_chat_messages
            WHERE league_id=?
            ORDER BY created_at DESC
            LIMIT ?
            """,
            (league_id, limit),
        ).fetchall()
    messages = [
        {
            "id": str(r["id"]),
            "user_id": str(r["user_id"]),
            "team_name": r["team_name"],
            "display_name": str(r["display_name"] or "Coach"),
            "body": str(r["body"] or ""),
            "created_at": int(r["created_at"] or 0),
            "time_label": _activity_time_label(int(r["created_at"] or 0)),
            "is_you": str(r["user_id"]) == user_id,
        }
        for r in rows
    ]
    messages.reverse()
    return messages


def post_league_chat_message(
    league_id: str,
    user_id: str,
    body: str,
    *,
    team_name: Optional[str] = None,
) -> Dict[str, Any]:
    _verify_league_member_or_owner(league_id, user_id)
    text = " ".join(str(body or "").split()).strip()
    if not text:
        raise ValueError("message required")
    if len(text) > 500:
        raise ValueError("message must be 500 characters or fewer")

    display = ""
    acting_team = str(team_name or "").strip() or None
    with db() as conn:
        mem = conn.execute(
            """
            SELECT team_name FROM league_members
            WHERE league_id=? AND user_id=? AND status='active'
            ORDER BY team_name IS NULL, team_name
            LIMIT 1
            """,
            (league_id, user_id),
        ).fetchone()
    if mem and mem["team_name"]:
        if not acting_team:
            acting_team = str(mem["team_name"])
        display = acting_team
    if not display:
        display = _user_email(user_id) or "Coach"
        if "@" in display:
            display = display.split("@", 1)[0]

    now = _now()
    msg_id = str(uuid.uuid4())
    with db() as conn:
        conn.execute(
            """
            INSERT INTO league_chat_messages
              (id, league_id, user_id, team_name, display_name, body, created_at)
            VALUES (?,?,?,?,?,?,?)
            """,
            (msg_id, league_id, user_id, acting_team, display, text, now),
        )
    return {
        "id": msg_id,
        "user_id": user_id,
        "team_name": acting_team,
        "display_name": display,
        "body": text,
        "created_at": now,
        "time_label": "Just now",
        "is_you": True,
    }
